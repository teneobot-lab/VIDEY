--========================================================
-- TOF HUB v4 | main.lua
-- Entry point: loader modul + siklus hidup (start / unload)
--
-- Tiga cara menjalankan (pilih salah satu):
--   1. Folder lokal : taruh folder TOFHub/ di workspace executor, jalankan main.lua
--   2. Online       : isi BASE_URL dengan URL folder (harus diakhiri "/")
--   3. Bundle       : TOFHub_bundle.lua (hasil build.py, semua modul jadi satu file)
--
-- Aturan modul: tiap file diawali `local Hub = ...` dan diakhiri `return <tabel/fungsi>`.
-- Ambil dependensi lewat Hub.use("folder/Nama"); hasilnya di-cache.
--========================================================
if getgenv and getgenv().TOFHubUnload then pcall(getgenv().TOFHubUnload) end

local ROOT = "TOFHub" -- nama folder di workspace executor (mode lokal)
local BASE_URL = nil  -- contoh: "https://raw.githubusercontent.com/user/repo/main/TOFHub/"

local BUNDLE = {
["config/Categories"] = function(...)
-- Kategori ESP (data-driven). Tambah kategori/objek baru = tambah satu baris di CATS.
--   kind  : "role" (pemain) | "npc" | "obj" (objek map, dicari lewat kata kunci nama)
--   on    : kunci Cfg untuk toggle tampil     col : kunci Cfg untuk warna
--   keyCfg/keyDef : (khusus obj) kunci Cfg kata kunci nama + nilai awalnya
-- Kunci turunan otomatis: chams = "Chams_<id>", label = "Label_<id>", dist = "Dist_<id>"
local CATS = {
    { id = "Killer", name = "Killer", kind = "role", on = "ESPKiller", col = "KillerColor", def = Color3.fromRGB(235, 50, 50) },
    { id = "Surv", name = "Survivor", kind = "role", on = "ESPSurv", col = "SurvColor", def = Color3.fromRGB(80, 220, 110) },
    { id = "Zombie", name = "Zombie", kind = "npc", on = "ESPZombie", col = "ZombieColor", def = Color3.fromRGB(150, 255, 60) },
    { id = "Gen", name = "Generator", kind = "obj", on = "ObjGen", col = "ColGen", def = Color3.fromRGB(255, 220, 60), keyCfg = "KeyGen", keyDef = "generator" },
    { id = "Hook", name = "Hook", kind = "obj", on = "ObjHook", col = "ColHook", def = Color3.fromRGB(255, 140, 40), keyCfg = "KeyHook", keyDef = "hook" },
    { id = "Gate", name = "Gate", kind = "obj", on = "ObjGate", col = "ColGate", def = Color3.fromRGB(60, 210, 230), keyCfg = "KeyGate", keyDef = "gate" },
    { id = "Pallet", name = "Pallet", kind = "obj", on = "ObjPallet", col = "ColPallet", def = Color3.fromRGB(190, 90, 255), keyCfg = "KeyPallet", keyDef = "pallet" },
    { id = "Window", name = "Window", kind = "obj", on = "ObjWindow", col = "ColWindow", def = Color3.fromRGB(80, 130, 255), keyCfg = "KeyWindow", keyDef = "window" },
}

local byId, objGroups = {}, {}
for _, c in ipairs(CATS) do
    byId[c.id] = c
    c.chams, c.label, c.dist = "Chams_" .. c.id, "Label_" .. c.id, "Dist_" .. c.id
    if c.kind == "obj" then objGroups[#objGroups + 1] = c end
end

return { list = CATS, byId = byId, objGroups = objGroups }
end,
["config/Config"] = function(...)
-- Konfigurasi: nilai awal, simpan/muat JSON, dan sinkronisasi ke komponen UI.
--   Config.Cfg          tabel nilai aktif (baca langsung: Cfg.FOV)
--   Config.Default      salinan nilai awal
--   Config.set(k,v[,s]) ubah nilai + segarkan UI + simpan otomatis (s = true: jangan tandai berubah)
--   Config.reg(k,f)     daftarkan fungsi yang dipanggil tiap Cfg[k] berubah lewat set()
--   Config.save()       simpan SEKARANG ke file          -> ok, pesan
--   Config.load()       muat dari file + segarkan UI     -> ok, pesan
--   Config.reset()      kembalikan semua ke default
--   Config.delete()     hapus file config                -> ok, pesan
--   Config.serialize()  config sebagai string JSON (untuk disalin)
--   Config.dirty        true bila ada perubahan yang belum tersimpan ke file
-- Opsi baru: tambah di tabel Cfg di bawah (kelompokkan per fitur).
local Hub = ...
local Http = game:GetService("HttpService")
local Util = Hub.use("core/Util")
local Cats = Hub.use("config/Categories")

local FILE = "TOFHub_config.json"

local Cfg = {
    Ver = 4,
    -- Aim
    Aimlock = false, Silent = false, WallCheck = false, ShowFOV = true,
    FOV = 200, Lock = 100, Predict = 0, Part = "HumanoidRootPart", AutoUnstick = true,
    FOVColor = Color3.fromRGB(240, 240, 245),
    -- Deteksi role
    KillerCount = 1, ManualKiller = "",
    -- ESP umum
    ShowLabels = true, -- saklar utama: mati = SEMUA label ESP (pemain, zombie, objek) hilang
    ShowName = true, ShowDist = true, ShowHP = true, ShowRole = true,
    GenBar = true, -- bar progres generator: tampil otomatis di generator yang sedang diperbaiki, tanpa perlu label
    GenHideDone = true, -- ESP generator mati otomatis saat progres penuh (100%)
    FillT = 65, TextSize = 12, ESPMode = "CoreGui",
    ZomAll = false, KeyZombie = "scp2, zombie",
    -- Dunia (lighting)
    Fullbright = false, Bright = 2, AmbientColor = Color3.fromRGB(210, 210, 210),
    ForceTime = false, Time = 14, NoFog = true, NoFx = false,
    -- Dunia (HD grafis)
    HD = false, HDPreset = "Tinggi", HDContrast = 12, HDSaturation = 14, HDBloom = 25,
    HDShadows = true, HDQuality = true, HDMesh = false, HDFuture = false,
    -- Gerak
    Speed = false, SpeedVal = 24, SpeedSafe = true, Noclip = false, Fly = false, FlySpeed = 50,
    -- Violence District
    VDAutoSkillCheck = false, VDSkillMode = "Perfect",
    VDSpeedBoost = false, VDSpeedMultiplier = 0.30, VDSpeedSafeMode = true,
    VDFastVault = false, VDVaultMult = 1.5, VDVaultForce = true, VDVaultAnim = true, VDVaultMode = "Atribut", VDVaultKeys = "vault",
    -- GUI
    Accent = Color3.fromRGB(124, 106, 255), Theme = "Overworld", ShowFloat = true, W = 420, H = 320,
    UIAnim = true,
    -- Config
    AutoSave = true,
}
-- kunci per kategori ESP (dibangkitkan dari config/Categories)
for _, c in ipairs(Cats.list) do
    Cfg[c.on] = true
    Cfg[c.col] = c.def
    Cfg[c.chams] = (c.kind ~= "obj") -- objek: label saja (hemat batas Highlight Roblox)
    Cfg[c.label] = true
    Cfg[c.dist] = 2000
    if c.keyCfg then Cfg[c.keyCfg] = c.keyDef end
end

local Default = {}
for k, v in pairs(Cfg) do Default[k] = v end

local Config = { Cfg = Cfg, Default = Default, FILE = FILE, dirty = false, lastSave = nil }
local Refresh = {}

--------------------------------------------------------
-- Simpan / muat
--------------------------------------------------------
local function serialize()
    local out = {}
    for k, v in pairs(Cfg) do
        if k ~= "ManualKiller" then
            if typeof(v) == "Color3" then out[k] = "#" .. Util.hex(v) else out[k] = v end
        end
    end
    return Http:JSONEncode(out)
end
Config.serialize = serialize

function Config.supported()
    return writefile ~= nil and readfile ~= nil and isfile ~= nil
end

function Config.exists()
    if not (readfile and isfile) then return false end
    local ok, r = pcall(isfile, FILE)
    return ok and r == true
end

function Config.save()
    if not writefile then return false, "Executor tidak punya writefile" end
    local ok, e = pcall(writefile, FILE, serialize())
    if not ok then return false, "Gagal menyimpan: " .. tostring(e) end
    Config.dirty = false
    Config.lastSave = os.time()
    return true, "Config disimpan"
end

-- simpan otomatis 1 detik setelah perubahan terakhir (bila AutoSave aktif)
local saveToken = 0
function Config.markDirty()
    Config.dirty = true
    if not (writefile and Cfg.AutoSave) then return end
    saveToken += 1
    local t = saveToken
    task.delay(1, function()
        if t ~= saveToken or Hub.Dead then return end
        Config.save()
    end)
end

local function readData()
    if not Config.exists() then return nil, "file config belum ada" end
    local ok, data = pcall(function() return Http:JSONDecode(readfile(FILE)) end)
    if not (ok and type(data) == "table") then return nil, "file config rusak" end
    -- config versi lama dilewati supaya default baru terpakai
    if data.Ver ~= Cfg.Ver then return nil, "versi config berbeda" end
    return data
end

-- salin nilai dari tabel hasil JSON ke Cfg. silent = true: tanpa menyegarkan UI (saat startup)
local function applyData(data, silent)
    local n = 0
    for k, v in pairs(data) do
        if Cfg[k] ~= nil and k ~= "ManualKiller" and k ~= "Ver" then
            local nv
            if typeof(Cfg[k]) == "Color3" then
                nv = Util.parseHex(v)
            elseif type(v) == type(Cfg[k]) then
                nv = v
            end
            if nv ~= nil then
                if silent then Cfg[k] = nv else Config.set(k, nv, true) end
                n += 1
            end
        end
    end
    return n
end

function Config.load()
    local data, err = readData()
    if not data then return false, "Gagal memuat: " .. err end
    local n = applyData(data, false)
    Config.dirty = false
    return true, ("Config dimuat (%d opsi)"):format(n)
end

function Config.reset()
    for k, v in pairs(Default) do
        if k ~= "Ver" and k ~= "ManualKiller" then Config.set(k, v, true) end
    end
    Config.markDirty()
end

function Config.delete()
    if not delfile then return false, "Executor tidak punya delfile" end
    if not Config.exists() then return false, "File config belum ada" end
    local ok, e = pcall(delfile, FILE)
    if not ok then return false, "Gagal menghapus: " .. tostring(e) end
    Config.dirty = true
    return true, "File config dihapus"
end

--------------------------------------------------------
-- Sinkronisasi UI
--------------------------------------------------------
function Config.reg(key, fn)
    Refresh[key] = Refresh[key] or {}
    table.insert(Refresh[key], fn)
end

function Config.set(key, v, silent)
    Cfg[key] = v
    for _, fn in ipairs(Refresh[key] or {}) do pcall(fn) end
    if not silent then Config.markDirty() end
end

-- muat saat startup (UI belum dibuat, jadi tanpa refresh)
do
    local data = readData()
    if data then applyData(data, true) end
end

-- simpan perubahan yang tertunda saat script di-unload
Hub.onUnload(function()
    if Config.dirty and Cfg.AutoSave then pcall(Config.save) end
end)

return Config
end,
["core/Roles"] = function(...)
-- Deteksi Killer vs Survivor dari sinyal tim, atribut, tag, dsb.
--   Roles.killers   daftar Player killer     Roles.killerMap[p] = true bila killer
--   Roles.info      daftar { p, killer, score, why } untuk Dashboard
--   Roles.detect()  dipanggil berkala         Roles.myRoot() / Roles.dump()
local Hub = ...
local Players = game:GetService("Players")
local CS = game:GetService("CollectionService")
local LP = Players.LocalPlayer
local Util = Hub.use("core/Util")
local Cfg = Hub.use("config/Config").Cfg
local Scheduler = Hub.use("core/Scheduler")

local Roles = { killers = {}, killerMap = {}, info = {} }

local function isStrBool(v) return type(v) == "string" or type(v) == "boolean" end

local function signalsOf(p)
    local ch = p.Character
    local ch_ = {}
    ch_["team"] = { v = p.Team and p.Team.Name or "-", w = 2 }
    local par = ch and ch.Parent
    ch_["folder"] = { v = (par and par ~= workspace) and par.Name or "-", w = 2 }
    for _, pair in ipairs({ { "P", p }, { "C", ch } }) do
        local obj = pair[2]
        if obj then
            for k, v in pairs(obj:GetAttributes()) do
                if isStrBool(v) then
                    local kl = tostring(k):lower()
                    local roleish = kl:find("kill") or kl:find("role") or kl:find("team") or kl:find("class")
                        or kl:find("side") or kl:find("surv")
                    ch_[pair[1] .. "." .. tostring(k)] = { v = tostring(v), w = roleish and 2 or 1 }
                end
            end
        end
    end
    local tg = ch and CS:GetTags(ch) or {}
    table.sort(tg)
    ch_["tags"] = { v = table.concat(tg, ","), w = 1 }
    ch_["ci"] = { v = tostring(ch ~= nil and ch:FindFirstChild("CheckInterractable") ~= nil), w = 1 }
    local hum = ch and ch:FindFirstChildOfClass("Humanoid")
    ch_["maxhp"] = { v = hum and tostring(hum.MaxHealth) or "-", w = 1 }
    return ch_
end

function Roles.detect()
    local plist = {}
    for _, p in ipairs(Players:GetPlayers()) do
        if p.Character then plist[#plist + 1] = p end
    end
    local N, K = #plist, math.max(1, Cfg.KillerCount)
    local sig, names = {}, {}
    for _, p in ipairs(plist) do
        sig[p] = signalsOf(p)
        for name in pairs(sig[p]) do names[name] = true end
    end

    local score, why = {}, {}
    local function add(p, n, r)
        if p == LP then return end
        score[p] = (score[p] or 0) + n
        why[p] = (why[p] or "") .. r .. " "
    end

    if N >= 3 then
        for name in pairs(names) do
            local groups, order, w = {}, {}, 1
            local kHits, sHits = {}, {}
            local nl = name:lower()
            for _, p in ipairs(plist) do
                local c = sig[p][name]
                local v = c and c.v or "-"
                if c then w = math.max(w, c.w) end
                if not groups[v] then groups[v] = {} order[#order + 1] = v end
                table.insert(groups[v], p)
                local vl = v:lower()
                if vl:find("killer") or (nl:find("killer") and vl == "true") then kHits[#kHits + 1] = p end
                if vl:find("surviv") or (nl:find("surviv") and vl == "true") then sHits[#sHits + 1] = p end
            end
            if #kHits >= 1 and #kHits <= K then
                for _, p in ipairs(kHits) do add(p, 3, name .. "=killer") end
            end
            if #sHits >= 2 and (N - #sHits) >= 1 and (N - #sHits) <= K then
                local set = {}
                for _, p in ipairs(sHits) do set[p] = true end
                for _, p in ipairs(plist) do
                    if not set[p] then add(p, 2, name .. "!=surv") end
                end
            end
            if #order == 2 then
                local a, b = groups[order[1]], groups[order[2]]
                local small, big = a, b
                if #b < #a then small, big = b, a end
                if #small <= K and #big >= 2 and #small < #big then
                    for _, p in ipairs(small) do add(p, w, name .. "~") end
                end
            end
        end
    end

    -- sinyal pasti dari atribut karakter (terbukti dari log game ini)
    local isSurv = {}
    for _, p in ipairs(plist) do
        local ch = p.Character
        if ch:GetAttribute("TerrorRadius") ~= nil or ch:GetAttribute("IsChasing") ~= nil
            or ch:GetAttribute("SuspenseRadius") ~= nil then
            add(p, 10, "attr-killer")
        elseif ch:GetAttribute("vaultspeed") ~= nil or ch:GetAttribute("healboost") ~= nil then
            isSurv[p] = true
        end
    end
    for p in pairs(isSurv) do score[p] = nil why[p] = nil end

    local cand = {}
    for p, s in pairs(score) do
        if s >= 2 then cand[#cand + 1] = p end
    end
    table.sort(cand, function(a, b)
        if score[a] ~= score[b] then return score[a] > score[b] end
        return a.UserId < b.UserId
    end)
    local killers = {}
    for i = 1, math.min(K, #cand) do
        local nxt = cand[i + 1]
        if i == K and nxt and score[nxt] == score[cand[i]] then break end
        killers[#killers + 1] = cand[i]
    end

    if Cfg.ManualKiller ~= "" then
        local mp = Players:FindFirstChild(Cfg.ManualKiller)
        if mp and mp ~= LP then
            killers = { mp }
            why[mp] = "manual "
            score[mp] = 99
        end
    end

    local map, info = {}, {}
    for _, p in ipairs(killers) do map[p] = true end
    for _, p in ipairs(plist) do
        info[#info + 1] = { p = p, killer = map[p] == true, score = score[p] or 0, why = why[p] or "" }
    end
    table.sort(info, function(a, b)
        if a.killer ~= b.killer then return a.killer end
        return a.p.Name < b.p.Name
    end)
    Roles.killers, Roles.killerMap, Roles.info = killers, map, info
end

function Roles.myRoot()
    return LP.Character and LP.Character:FindFirstChild("HumanoidRootPart")
end

-- teks diagnostik untuk disalin (tombol di Dashboard)
function Roles.dump()
    local out = {}
    for _, p in ipairs(Players:GetPlayers()) do
        local ch = p.Character
        out[#out + 1] = ("== %s%s | team=%s | char=%s"):format(p.Name, p == LP and " (ME)" or "", tostring(p.Team), ch and Util.pathOf(ch) or "nil")
        for _, pair in ipairs({ { "P", p }, { "C", ch } }) do
            if pair[2] then
                for k, v in pairs(pair[2]:GetAttributes()) do
                    out[#out + 1] = ("  %s.%s = %s"):format(pair[1], k, tostring(v))
                end
            end
        end
        if ch then
            local hum = ch:FindFirstChildOfClass("Humanoid")
            out[#out + 1] = ("  tags=%s maxhp=%s ci=%s"):format(table.concat(CS:GetTags(ch), ","),
                hum and tostring(hum.MaxHealth) or "-", tostring(ch:FindFirstChild("CheckInterractable") ~= nil))
            local kids = {}
            for i, c in ipairs(ch:GetChildren()) do
                if i > 40 then kids[#kids + 1] = "..." break end
                kids[#kids + 1] = c.ClassName .. ":" .. c.Name
            end
            out[#out + 1] = "  children=" .. table.concat(kids, ", ")
        end
    end
    for _, e in ipairs(Roles.info) do
        out[#out + 1] = ("[hasil] %s killer=%s skor=%d %s"):format(e.p.Name, tostring(e.killer), e.score, e.why)
    end
    return table.concat(out, "\n")
end

Hub.safe("Role", Roles.detect)
Scheduler.add("Role", 0.5, Roles.detect)

return Roles
end,
["core/Scheduler"] = function(...)
-- Satu Heartbeat untuk semua tugas berkala.
-- Pakai: Scheduler.add("Nama", interval_detik, fn)   (interval 0 = tiap frame)
-- Error tiap tugas ditangkap Hub.safe dan tampil di Dashboard > Diagnostik.
local Hub = ...
local RunService = game:GetService("RunService")

local Scheduler = { fps = 60, tasks = {} }

function Scheduler.add(name, interval, fn)
    Scheduler.tasks[#Scheduler.tasks + 1] = { name = name, interval = interval, fn = fn, acc = 0 }
end

Hub.track(RunService.Heartbeat:Connect(function(dt)
    if Hub.Dead then return end
    Scheduler.fps = Scheduler.fps * 0.9 + (1 / math.max(dt, 1e-3)) * 0.1
    for _, t in ipairs(Scheduler.tasks) do
        if t.interval <= 0 then
            Hub.safe(t.name, t.fn, dt)
        else
            t.acc += dt
            if t.acc >= t.interval then
                t.acc = 0
                Hub.safe(t.name, t.fn, dt)
            end
        end
    end
end))

return Scheduler
end,
["core/Util"] = function(...)
-- Fungsi kecil murni (tanpa state) yang dipakai banyak modul
local Util = {}

-- nama root di workspace yang diabaikan saat mencari NPC / objek
Util.SKIP_TOP = { Lobby = true, FakeCharacters = true, Clones = true, Terrain = true, Camera = true }

function Util.hex(c)
    return string.format("%02X%02X%02X", math.floor(c.R * 255 + 0.5), math.floor(c.G * 255 + 0.5), math.floor(c.B * 255 + 0.5))
end

function Util.parseHex(s)
    s = tostring(s):gsub("#", ""):gsub("%s", "")
    if #s == 6 and s:match("^%x+$") then
        return Color3.fromRGB(tonumber(s:sub(1, 2), 16), tonumber(s:sub(3, 4), 16), tonumber(s:sub(5, 6), 16))
    end
end

function Util.pathOf(i)
    local ok, r = pcall(function() return i:GetFullName() end)
    return ok and r or tostring(i)
end

-- "a, b  c" -> { "a", "b", "c" } (huruf kecil)
function Util.splitKeys(s)
    local t = {}
    for w in tostring(s):gmatch("[^,%s]+") do t[#t + 1] = w:lower() end
    return t
end

-- nama anak workspace paling atas dari sebuah instance
function Util.topName(inst)
    local p = inst
    while p.Parent and p.Parent ~= workspace do p = p.Parent end
    return p.Name
end

-- escape untuk RichText
function Util.esc(s)
    s = tostring(s)
    s = s:gsub("&", "&amp;")
    s = s:gsub("<", "&lt;")
    s = s:gsub(">", "&gt;")
    return s
end

return Util
end,
["esp/Draw"] = function(...)
-- Helper gambar ESP bersama: label (BillboardGui) + bar progres + chams (Highlight).
-- Setiap objek ESP memegang "rec" ({ bb, tl, bar, hl, ... }); helper ini yang membuat/memindah/menghapusnya.
-- Draw.label menghormati saklar utama Cfg.ShowLabels: bila mati, SEMUA teks label (pemain, zombie, objek) hilang.
-- Bar progres berdiri sendiri: tetap tampil walau teks label mati (text = nil), selama `bar` diberikan.
local Hub = ...
local Cfg = Hub.use("config/Config").Cfg
local Kit = Hub.use("ui/Kit")
local new, corner, tween = Kit.new, Kit.corner, Kit.tween
local espFolder = Hub.use("ui/Root").espFolder
local Scheduler = Hub.use("core/Scheduler")

local Draw = { bars = {} }

local BAR_W, BAR_H = 96, 9
local RED, YEL, GRN = Color3.fromRGB(235, 70, 60), Color3.fromRGB(255, 205, 55), Color3.fromRGB(80, 225, 110)
local INK = Color3.fromRGB(14, 10, 10)

local function barColor(p)
    if p < 0.5 then return RED:Lerp(YEL, p * 2) end
    return YEL:Lerp(GRN, (p - 0.5) * 2)
end

function Draw.dropBar(rec)
    if rec.bar then
        Draw.bars[rec] = nil
        pcall(function() rec.bar.track:Destroy() end)
        rec.bar = nil
    end
end
function Draw.dropBB(rec)
    Draw.bars[rec] = nil
    rec.bar = nil
    if rec.bb then pcall(function() rec.bb:Destroy() end) rec.bb, rec.tl = nil, nil end
end
function Draw.dropHL(rec)
    if rec.hl then pcall(function() rec.hl:Destroy() end) rec.hl = nil end
end
function Draw.dropGui(rec) Draw.dropBB(rec) Draw.dropHL(rec) end

local function ensureBB(rec, w, h, off)
    if not rec.bb then
        rec.bb = new("BillboardGui", {
            Name = "TOFTag", Size = UDim2.fromOffset(w, h), StudsOffset = Vector3.new(0, off, 0),
            AlwaysOnTop = true, ResetOnSpawn = false,
        })
        rec.tl = new("TextLabel", {
            Size = UDim2.new(1, 0, 0, h), BackgroundTransparency = 1,
            Font = Enum.Font.GothamBold, TextSize = 12, TextStrokeTransparency = 0.4,
        }, rec.bb)
    end
    rec.tl.Size = UDim2.new(1, 0, 0, h)
end

-- bar progres kecil di bawah teks: isi bergeser warna merah -> kuning -> hijau, ada kilau berjalan
local function ensureBar(rec)
    if rec.bar then return end
    local track = new("Frame", {
        Name = "Bar", AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, 3),
        Size = UDim2.fromOffset(BAR_W, BAR_H), BackgroundColor3 = Color3.fromRGB(30, 26, 24), BorderSizePixel = 0,
    }, rec.bb)
    corner(track, 4)
    new("UIStroke", { Color = INK, Thickness = 1.5, ApplyStrokeMode = Enum.ApplyStrokeMode.Border }, track)
    local fill = new("Frame", { Size = UDim2.new(0, 0, 1, 0), BorderSizePixel = 0, BackgroundColor3 = RED }, track)
    corner(fill, 4)
    local grad = new("UIGradient", {
        Color = ColorSequence.new({
            ColorSequenceKeypoint.new(0, Color3.fromRGB(185, 185, 185)),
            ColorSequenceKeypoint.new(0.5, Color3.new(1, 1, 1)),
            ColorSequenceKeypoint.new(1, Color3.fromRGB(185, 185, 185)),
        }),
    }, fill)
    -- garis pembagi 25% / 50% / 75%
    for _, x in ipairs({ 0.25, 0.5, 0.75 }) do
        new("Frame", {
            AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(x, 0, 0, 0), Size = UDim2.new(0, 1, 1, 0),
            BackgroundColor3 = INK, BackgroundTransparency = 0.45, BorderSizePixel = 0, ZIndex = 2,
        }, track)
    end
    rec.bar = { track = track, fill = fill, grad = grad }
    Draw.bars[rec] = true
end

local function placeBB(rec, part)
    rec.bb.Adornee = part
    local want = (Cfg.ESPMode == "Workspace") and part or espFolder
    if rec.bb.Parent ~= want then rec.bb.Parent = want end
end

local function ensureHL(rec)
    if not rec.hl then
        rec.hl = new("Highlight", { Name = "TOFHL", DepthMode = Enum.HighlightDepthMode.AlwaysOnTop })
    end
end

local function placeHL(rec, adornee)
    rec.hl.Adornee = adornee
    local want = (Cfg.ESPMode == "Workspace") and adornee or espFolder
    if rec.hl.Parent ~= want then rec.hl.Parent = want end
end

-- label di atas `part` (ukuran w x h px, naik `off` stud).
--   text = nil          -> tanpa teks (hanya bar, bila ada)
--   bar  = 0..1 (opsional) -> bar progres (di bawah teks, atau sendirian bila tanpa teks)
-- Saklar utama Cfg.ShowLabels = mati menghapus TEKS semua ESP; bar tidak ikut mati.
function Draw.label(rec, w, h, off, col, text, part, bar)
    if not Cfg.ShowLabels then text = nil end
    if text == nil and bar == nil then Draw.dropBB(rec) return end
    ensureBB(rec, w, h, off)
    local hasText = text ~= nil
    rec.tl.Visible = hasText
    if hasText then
        rec.tl.TextColor3 = col
        rec.tl.TextSize = Cfg.TextSize
        rec.tl.Text = text
    end
    local th = hasText and h or 0
    if bar ~= nil then
        ensureBar(rec)
        bar = math.clamp(bar, 0, 1)
        rec.bar.track.Position = UDim2.new(0.5, 0, 0, hasText and (h + 3) or 3)
        rec.bb.Size = UDim2.fromOffset(w, th + BAR_H + 6)
        tween(rec.bar.fill, { Size = UDim2.new(bar, 0, 1, 0), BackgroundColor3 = barColor(bar) }, 0.3)
    else
        if rec.bar then Draw.dropBar(rec) end
        rec.bb.Size = UDim2.fromOffset(w, th)
    end
    placeBB(rec, part)
end

-- chams (outline + isi) pada `adornee`
function Draw.chams(rec, adornee, col, fillT)
    ensureHL(rec)
    rec.hl.FillColor, rec.hl.OutlineColor = col, col
    rec.hl.FillTransparency = fillT
    placeHL(rec, adornee)
end

-- kilau yang berjalan di semua bar yang sedang tampil
Scheduler.add("ESP bar anim", 0.05, function()
    if not Kit.animOn() then return end
    local o = ((os.clock() * 0.7) % 2) - 1
    for rec in pairs(Draw.bars) do
        local b = rec.bar
        if b and b.grad.Parent then
            b.grad.Offset = Vector2.new(o, 0)
        else
            Draw.bars[rec] = nil
        end
    end
end)

return Draw
end,
["esp/Objects"] = function(...)
-- ESP objek map (generator, hook, gate, pallet, window) lewat kata kunci nama di workspace.Map.
-- Grup objek diambil dari config/Categories (kind = "obj"). Teks label khusus per objek
-- ditambahkan lewat LABEL_HOOKS (kunci = id kategori), jadi menambah objek baru tidak perlu ubah update().
local Hub = ...
local CS = game:GetService("CollectionService")
local Cfg = Hub.use("config/Config").Cfg
local OBJ_GROUPS = Hub.use("config/Categories").objGroups
local Util = Hub.use("core/Util")
local Roles = Hub.use("core/Roles")
local Draw = Hub.use("esp/Draw")
local Scheduler = Hub.use("core/Scheduler")

local Obj = { tracked = {}, shown = {} }

function Obj.rebuildKeys()
    for _, g in ipairs(OBJ_GROUPS) do g.keys = Util.splitKeys(Cfg[g.keyCfg]) end
end
Obj.rebuildKeys()

local function groupOf(name)
    local l = name:lower()
    for _, g in ipairs(OBJ_GROUPS) do
        for _, k in ipairs(g.keys) do
            if l:find(k, 1, true) then return g, k end
        end
    end
end

local function insideCharacter(inst)
    local p = inst.Parent
    while p and p ~= workspace do
        if p:IsA("Model") and p:FindFirstChildOfClass("Humanoid") then return true end
        p = p.Parent
    end
    return false
end

local function hasTrackedAncestor(inst)
    local p = inst.Parent
    while p and p ~= workspace do
        if Obj.tracked[p] then return true end
        p = p.Parent
    end
    return false
end

local function isContainer(inst, key)
    if not inst:IsA("Model") then return false end
    if inst.Name:sub(-1):lower() ~= "s" then return false end
    for _, c in ipairs(inst:GetChildren()) do
        if c:IsA("Model") and c.Name:lower():find(key, 1, true) then return true end
    end
    return false
end

function Obj.untrack(inst)
    local rec = Obj.tracked[inst]
    if rec then
        Draw.dropGui(rec)
        pcall(function() rec.conn:Disconnect() end)
        Obj.tracked[inst] = nil
    end
end

function Obj.consider(inst)
    if Obj.tracked[inst] then return end
    if not (inst:IsA("Model") or inst:IsA("BasePart")) then return end
    local g, key = groupOf(inst.Name)
    if not g then return end
    -- hanya di dalam workspace.Map (membuang dekor Lobby); jika Map belum ada, abaikan Lobby/FakeCharacters
    local map = workspace:FindFirstChild("Map")
    if map then
        if not inst:IsDescendantOf(map) then return end
    elseif Util.SKIP_TOP[Util.topName(inst)] then
        return
    end
    if g.id == "Gate" and not inst:IsA("Model") then return end -- Part "gate" bertag gatespot = titik spawn
    if inst:FindFirstChildOfClass("Humanoid") then return end
    if hasTrackedAncestor(inst) or isContainer(inst, key) or insideCharacter(inst) then return end
    if inst:IsA("Model") then
        for other in pairs(Obj.tracked) do
            if other ~= inst and other:IsDescendantOf(inst) then Obj.untrack(other) end
        end
    end
    local rec = { inst = inst, g = g }
    rec.conn = inst.AncestryChanged:Connect(function()
        if not inst:IsDescendantOf(workspace) then Obj.untrack(inst) end
    end)
    Obj.tracked[inst] = rec
end

function Obj.rescan()
    Obj.rebuildKeys()
    for inst in pairs(Obj.tracked) do Obj.untrack(inst) end
    task.spawn(function()
        local n = 0
        for _, d in ipairs(workspace:GetDescendants()) do
            if Hub.Dead then return end
            Obj.consider(d)
            n += 1
            if n % 2000 == 0 then task.wait() end
        end
    end)
end
Hub.track(workspace.DescendantAdded:Connect(function(d)
    task.defer(function() if not Hub.Dead then Obj.consider(d) end end)
end))

local function progressOf(inst)
    for k, v in pairs(inst:GetAttributes()) do
        local kl = tostring(k):lower()
        if type(v) == "number" and (kl:find("progress") or kl:find("percent")) then
            return math.floor(v + 0.5) -- RepairProgress berskala 0..100
        end
    end
    for _, c in ipairs(inst:GetChildren()) do
        if c:IsA("NumberValue") or c:IsA("IntValue") then
            local nl = c.Name:lower()
            if nl:find("progress") or nl:find("percent") then return math.floor(c.Value + 0.5) end
        end
    end
end

-- teks tambahan per jenis objek: fn(rec, teksDasar) -> teksBaru
-- Generator: bila bar dimatikan (Cfg.GenBar) progres kembali jadi teks persen.
local LABEL_HOOKS = {
    Gen = function(rec, txt)
        local pr = rec.pr
        if not pr then return txt end
        if pr >= 100 then return txt .. " [SELESAI]" end
        if not Cfg.GenBar then return txt .. " " .. pr .. "%" end
        return txt
    end,
    Hook = function(rec, txt)
        if not CS:HasTag(rec.inst, "Spike") then return txt .. " [TERISI]" end
        return txt
    end,
}

-- bar progres per jenis objek: fn(rec) -> 0..1 atau nil.
-- BERDIRI SENDIRI dari label: tampil otomatis walau label dimatikan.
-- Generator: bar muncul begitu survivor sudah memulai perbaikan (progres > 0).
local BAR_HOOKS = {
    Gen = function(rec)
        if Cfg.GenBar and rec.pr and rec.pr > 0 then return rec.pr / 100 end
    end,
}

function Obj.update()
    local myRoot = Roles.myRoot()
    local list = {}
    for inst, rec in pairs(Obj.tracked) do
        local part = rec.part
        if not (part and part.Parent) then
            part = inst:IsA("BasePart") and inst or inst.PrimaryPart or inst:FindFirstChildWhichIsA("BasePart", true)
            rec.part = part
        end
        local g = rec.g
        local dist = (part and myRoot) and (part.Position - myRoot.Position).Magnitude or 0
        -- generator yang sudah penuh: seluruh ESP-nya (label, bar, chams) dimatikan
        local done = false
        if g.id == "Gen" then
            local pr = progressOf(inst)
            rec.pr = pr and math.clamp(pr, 0, 100) or nil
            done = Cfg.GenHideDone and rec.pr ~= nil and rec.pr >= 100
        end
        if Cfg[g.on] and part and dist <= Cfg[g.dist] and not done then
            rec.dist = dist
            list[#list + 1] = rec
        else
            Draw.dropGui(rec)
        end
    end
    table.sort(list, function(a, b) return a.dist < b.dist end)
    local shown, hlCount = {}, 0
    for _, g in ipairs(OBJ_GROUPS) do shown[g.id] = 0 end
    for _, rec in ipairs(list) do
        local g = rec.g
        local ok = pcall(function()
            local col = Cfg[g.col]
            -- teks label: saklar utama Cfg.ShowLabels (dicek di Draw.label) + saklar per objek.
            -- bar progres: terpisah dari label, tampil sendiri bila ada.
            local txt = nil
            if Cfg[g.label] then
                txt = g.name
                local hook = LABEL_HOOKS[g.id]
                if hook then txt = hook(rec, txt) end
                if Cfg.ShowDist then txt = txt .. "  " .. math.floor(rec.dist) .. "m" end
            end
            local barHook = BAR_HOOKS[g.id]
            Draw.label(rec, 200, 18, 2, col, txt, rec.part, barHook and barHook(rec) or nil)
            if Cfg[g.chams] and hlCount < 16 then
                hlCount += 1
                Draw.chams(rec, rec.inst, col, 0.75)
            else
                Draw.dropHL(rec)
            end
        end)
        if ok then shown[g.id] += 1 else Draw.dropGui(rec) end
    end
    Obj.shown = shown
end

function Obj.clearAll()
    for inst in pairs(Obj.tracked) do Obj.untrack(inst) end
end

Scheduler.add("ESP objek", 0.2, Obj.update)
Hub.onUnload(Obj.clearAll)
Obj.rescan()

return Obj
end,
["esp/Players"] = function(...)
-- ESP pemain (Killer / Survivor). ESP.update() dipanggil Scheduler tiap 0.2 detik.
local Hub = ...
local Players = game:GetService("Players")
local LP = Players.LocalPlayer
local Cfg = Hub.use("config/Config").Cfg
local CAT = Hub.use("config/Categories").byId
local Roles = Hub.use("core/Roles")
local Draw = Hub.use("esp/Draw")
local Scheduler = Hub.use("core/Scheduler")

local ESP = { rec = {}, shown = { Killer = 0, Surv = 0 } }

function ESP.clear(p)
    local r = ESP.rec[p]
    if r then Draw.dropGui(r) ESP.rec[p] = nil end
end
function ESP.clearAll()
    for p in pairs(ESP.rec) do ESP.clear(p) end
end

function ESP.update()
    local myRoot = Roles.myRoot()
    local shown = { Killer = 0, Surv = 0 }
    for _, p in ipairs(Players:GetPlayers()) do
        local ch = p.Character
        local drawn = false
        if p ~= LP and ch then
            local isK = Roles.killerMap[p] == true
            local cat = isK and CAT.Killer or CAT.Surv
            local hum = ch:FindFirstChildOfClass("Humanoid")
            local root = ch:FindFirstChild("HumanoidRootPart")
            if Cfg[cat.on] and hum and hum.Health > 0 and root then
                local dist = myRoot and (root.Position - myRoot.Position).Magnitude or 0
                if dist <= Cfg[cat.dist] then
                    local rec = ESP.rec[p] or {}
                    ESP.rec[p] = rec
                    local ok = pcall(function()
                        local col = Cfg[cat.col]
                        if Cfg[cat.chams] then
                            Draw.chams(rec, ch, col, Cfg.FillT / 100)
                        else
                            Draw.dropHL(rec)
                        end
                        local parts, head, info = {}, {}, {}
                        if Cfg.ShowRole and isK then head[#head + 1] = "[KILLER]" end
                        if Cfg.ShowName then head[#head + 1] = p.DisplayName end
                        if #head > 0 then parts[#parts + 1] = table.concat(head, " ") end
                        if Cfg.ShowDist then info[#info + 1] = math.floor(dist) .. "m" end
                        if Cfg.ShowHP then info[#info + 1] = math.floor(hum.Health) .. " HP" end
                        if #info > 0 then parts[#parts + 1] = table.concat(info, " | ") end
                        if Cfg[cat.label] and #parts > 0 then
                            Draw.label(rec, 220, 50, 3, col, table.concat(parts, "\n"), ch:FindFirstChild("Head") or root)
                        else
                            Draw.dropBB(rec)
                        end
                    end)
                    if ok then
                        drawn = true
                        shown[cat.id] += 1
                    else
                        Draw.dropGui(rec)
                    end
                end
            end
        end
        if not drawn then ESP.clear(p) end
    end
    ESP.shown = shown
end

Hub.track(Players.PlayerRemoving:Connect(ESP.clear))
Scheduler.add("ESP pemain", 0.2, ESP.update)
Hub.onUnload(ESP.clearAll)

return ESP
end,
["esp/Zombies"] = function(...)
-- ESP zombie (NPC berhumanoid selain pemain).
-- Dugaan dari log: "scp2" = zombie SCP-049-2 milik killer Cure. Kata kunci diatur lewat Cfg.KeyZombie.
local Hub = ...
local Players = game:GetService("Players")
local Cfg = Hub.use("config/Config").Cfg
local CAT = Hub.use("config/Categories").byId
local Util = Hub.use("core/Util")
local Roles = Hub.use("core/Roles")
local Draw = Hub.use("esp/Draw")
local Scheduler = Hub.use("core/Scheduler")

local Zom = { tracked = {}, keys = {}, shown = 0 }

function Zom.rebuild() Zom.keys = Util.splitKeys(Cfg.KeyZombie) end
Zom.rebuild()

function Zom.matches(model)
    local nl = model.Name:lower()
    for _, k in ipairs(Zom.keys) do
        if nl:find(k, 1, true) then return true end
    end
    return false
end

function Zom.untrack(model)
    local rec = Zom.tracked[model]
    if rec then Draw.dropGui(rec) Zom.tracked[model] = nil end
end

function Zom.consider(model)
    if not model or Zom.tracked[model] or not model:IsA("Model") then return end
    if not model:IsDescendantOf(workspace) then return end
    local hum = model:FindFirstChildOfClass("Humanoid")
    if not hum then return end
    if Players:GetPlayerFromCharacter(model) then return end
    if model.Name == "cutscenecam" or Util.SKIP_TOP[Util.topName(model)] then return end
    Zom.tracked[model] = { model = model, hum = hum }
end

-- scan awal (dicicil supaya tidak membekukan game) + pantau yang baru muncul
task.spawn(function()
    local n = 0
    for _, d in ipairs(workspace:GetDescendants()) do
        if Hub.Dead then return end
        if d:IsA("Humanoid") then Zom.consider(d.Parent) end
        n += 1
        if n % 2000 == 0 then task.wait() end
    end
end)
Hub.track(workspace.DescendantAdded:Connect(function(d)
    if d:IsA("Humanoid") then
        task.defer(function() if not Hub.Dead and d.Parent then Zom.consider(d.Parent) end end)
    end
end))

function Zom.update()
    local cat = CAT.Zombie
    local myRoot = Roles.myRoot()
    local list = {}
    for model, rec in pairs(Zom.tracked) do
        local hum = rec.hum
        if not model.Parent or not hum or not hum.Parent then
            Zom.untrack(model)
        else
            local root = model:FindFirstChild("HumanoidRootPart") or model.PrimaryPart or model:FindFirstChildWhichIsA("BasePart")
            local dist = (root and myRoot) and (root.Position - myRoot.Position).Magnitude or 0
            if Cfg[cat.on] and hum.Health > 0 and root and dist <= Cfg[cat.dist]
                and (Cfg.ZomAll or Zom.matches(model)) then
                rec.root, rec.dist = root, dist
                list[#list + 1] = rec
            else
                Draw.dropGui(rec)
            end
        end
    end
    table.sort(list, function(a, b) return a.dist < b.dist end)
    local col = Cfg[cat.col]
    for i, rec in ipairs(list) do
        local ok = pcall(function()
            if Cfg[cat.label] then
                local info = {}
                if Cfg.ShowDist then info[#info + 1] = math.floor(rec.dist) .. "m" end
                if Cfg.ShowHP then info[#info + 1] = math.floor(rec.hum.Health) .. " HP" end
                local text = "ZOMBIE" .. (#info > 0 and ("\n" .. table.concat(info, " | ")) or "")
                Draw.label(rec, 180, 44, 3, col, text, rec.model:FindFirstChild("Head") or rec.root)
            else
                Draw.dropBB(rec)
            end
            if Cfg[cat.chams] and i <= 8 then
                Draw.chams(rec, rec.model, col, Cfg.FillT / 100)
            else
                Draw.dropHL(rec)
            end
        end)
        if not ok then Draw.dropGui(rec) end
    end
    Zom.shown = #list
end

function Zom.clearAll()
    for m in pairs(Zom.tracked) do Zom.untrack(m) end
end

Scheduler.add("ESP zombie", 0.2, Zom.update)
Hub.onUnload(Zom.clearAll)

return Zom
end,
["features/Aim"] = function(...)
-- Aimlock + Silent aim ke Killer, reset pose, dan hitung peluru "Twist of Fate".
--   Aim.step()     dipanggil tiap RenderStep (bind "TOFHubAim")
--   Aim.unstick()  paksa keluar dari pose bidik yang macet
local Hub = ...
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local UIS = game:GetService("UserInputService")
local RS = game:GetService("ReplicatedStorage")
local CS = game:GetService("CollectionService")
local LP = Players.LocalPlayer
local Cfg = Hub.use("config/Config").Cfg
local Roles = Hub.use("core/Roles")
local Scheduler = Hub.use("core/Scheduler")

local Aim = { targetName = nil, fireDir = nil, shoot = 0, fail = 0 }

local rp = RaycastParams.new()
rp.FilterType = Enum.RaycastFilterType.Exclude

local function visible(part)
    if not Cfg.WallCheck then return true end
    local f = { part.Parent }
    if LP.Character then f[2] = LP.Character end
    rp.FilterDescendantsInstances = f
    local o = workspace.CurrentCamera.CFrame.Position
    return workspace:Raycast(o, part.Position - o, rp) == nil
end

function Aim.getTarget()
    local cam = workspace.CurrentCamera
    local center = cam.ViewportSize / 2
    local best, bestP, bd = nil, nil, Cfg.FOV
    for _, p in ipairs(Roles.killers) do
        local ch = p.Character
        if ch then
            local hum = ch:FindFirstChildOfClass("Humanoid")
            local part = ch:FindFirstChild(Cfg.Part) or ch:FindFirstChild("HumanoidRootPart")
            if hum and hum.Health > 0 and part then
                local pos, on = cam:WorldToViewportPoint(part.Position)
                if on then
                    local d = (Vector2.new(pos.X, pos.Y) - center).Magnitude
                    if d < bd and visible(part) then best, bestP, bd = part, p, d end
                end
            end
        end
    end
    return best, bestP
end

function Aim.point(part)
    return part.Position + part.AssemblyLinearVelocity * (Cfg.Predict / 100)
end

function Aim.unstick()
    pcall(function()
        for _, n in ipairs({ "ShiftLock", "CameraTransition", "CameraDelay" }) do
            RunService:UnbindFromRenderStep(n)
        end
        local ch = LP.Character
        if not ch then return end
        ch:SetAttribute("Aiming", false)
        local hrp = ch:FindFirstChild("HumanoidRootPart")
        if hrp and CS:HasTag(hrp, "doing action") then CS:RemoveTag(hrp, "doing action") end
        local hum = ch:FindFirstChildOfClass("Humanoid")
        if hum then
            hum.AutoRotate = true
            local animator = hum:FindFirstChildOfClass("Animator")
            if animator then
                for _, tr in ipairs(animator:GetPlayingAnimationTracks()) do
                    local v = tr.Priority.Value
                    if v >= 2 and v < 1000 then tr:Stop(0.1) end
                end
            end
        end
    end)
end

-- Silent aim: hook tidak memanggil method Roblox apa pun; arah dihitung di RenderStep
local function hookFire()
    local Fire
    pcall(function() Fire = RS.Remotes.Items["Twist of Fate"].Fire end)
    if not Fire then return end

    Hub.track(Fire.OnClientEvent:Connect(function(kind)
        if kind == "Shoot" then Aim.shoot += 1
        elseif kind == "SelfDamage" then Aim.fail += 1 end
    end))

    if hookmetamethod and newcclosure and getnamecallmethod then
        local old
        old = hookmetamethod(game, "__namecall", newcclosure(function(self, ...)
            local method = getnamecallmethod()
            if method == "FireServer" and self == Fire and Cfg.Silent and not Hub.Dead then
                local dir = Aim.fireDir
                if dir then
                    local args = table.pack(...)
                    args[2] = dir
                    if setnamecallmethod then setnamecallmethod(method) end
                    return old(self, table.unpack(args, 1, args.n))
                end
            end
            return old(self, ...)
        end))
    end
end
hookFire()

function Aim.step()
    Aim.targetName, Aim.fireDir = nil, nil
    if not (Cfg.Aimlock or Cfg.Silent) then return end
    local cam = workspace.CurrentCamera
    local ok, t, p = pcall(Aim.getTarget)
    if not (ok and t) then return end
    Aim.targetName = p.DisplayName
    local pt = Aim.point(t)
    if Cfg.Silent then Aim.fireDir = (pt - cam.CFrame.Position).Unit end

    if Cfg.Aimlock then
        local ch = LP.Character
        if ch and ch:GetAttribute("Aiming") then
            local goal = CFrame.lookAt(cam.CFrame.Position, pt)
            cam.CFrame = cam.CFrame:Lerp(goal, Cfg.Lock / 100)
        end
    end
end
RunService:BindToRenderStep("TOFHubAim", Enum.RenderPriority.Last.Value, Aim.step)

-- watchdog: Aiming menyala padahal tombol bidik tidak ditahan (PC) -> reset pose
local stuckT = 0
local function watchdog(dt)
    if not (Cfg.AutoUnstick and UIS.KeyboardEnabled and UIS.MouseEnabled) then return end
    local ch = LP.Character
    if ch and ch:GetAttribute("Aiming") then
        local held = UIS:IsMouseButtonPressed(Enum.UserInputType.MouseButton2)
            or UIS:IsGamepadButtonDown(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonL2)
        stuckT = held and 0 or (stuckT + dt)
        if stuckT > 0.8 then
            stuckT = 0
            Aim.unstick()
        end
    else
        stuckT = 0
    end
end
Scheduler.add("Aim watchdog", 0, watchdog)

Hub.onUnload(function()
    Cfg.Aimlock, Cfg.Silent = false, false
    pcall(function() RunService:UnbindFromRenderStep("TOFHubAim") end)
end)

return Aim
end,
["features/AutoSkillCheck"] = function(...)
-- Violence District: Auto Skill Check + Speed Boost (porting dari violence_district.lua).
-- Mode skill check: Perfect | Normal | Instant. Dijalankan Scheduler tiap 0.05 detik.
-- Catatan: Speed Boost memakai WalkSpeed juga seperti features/Movement; jangan aktifkan keduanya bersamaan.
local Hub = ...
local Players = game:GetService("Players")
local GuiService = game:GetService("GuiService")
local LP = Players.LocalPlayer
local Cfg = Hub.use("config/Config").Cfg
local Scheduler = Hub.use("core/Scheduler")

local VIM
pcall(function() VIM = game:GetService("VirtualInputManager") end)

local VD = {}
local playerGui
local lastGoalRotation
local lastPress = 0
local speedRecords = {}
local cachedAction

local function getPlayerGui()
    playerGui = LP:FindFirstChildOfClass("PlayerGui") or playerGui
    return playerGui
end

local function findSkillCheck()
    local pg = getPlayerGui()
    if not pg then return nil, nil end
    for _, name in ipairs({ "SkillCheckPromptGui", "SkillCheckPromptGui-con" }) do
        local gui = pg:FindFirstChild(name, true)
        if gui then
            local check = gui:FindFirstChild("Check", true)
            if check and check.Visible then
                return check:FindFirstChild("Line", true), check:FindFirstChild("Goal", true)
            end
        end
    end
    return nil, nil
end

local function findActionButton()
    local pg = getPlayerGui()
    if not pg then return nil end
    if cachedAction and cachedAction.Parent and cachedAction:IsA("GuiButton") then
        return cachedAction
    end
    cachedAction = nil
    local mobile = pg:FindFirstChild("Survivor-mob", true)
    local controls = mobile and mobile:FindFirstChild("Controls", true)
    if not controls then return nil end
    for _, name in ipairs({ "action", "Gui-mob" }) do
        local b = controls:FindFirstChild(name, true)
        if b and b:IsA("GuiButton") then
            cachedAction = b
            return b
        end
    end
    return nil
end

local function pressSkillCheck()
    local button = findActionButton()
    if button and type(firesignal) == "function" then
        local ok = pcall(function()
            firesignal(button.MouseButton1Down)
            task.delay(0.04, function()
                if button and button.Parent then
                    pcall(function() firesignal(button.MouseButton1Up) end)
                    pcall(function() firesignal(button.MouseButton1Click) end)
                end
            end)
        end)
        if ok then return true end
    end

    if not VIM then return false end

    local pg = getPlayerGui()
    local check = pg and (pg:FindFirstChild("Check", true) or pg:FindFirstChild("check", true))
    if check and check:IsA("GuiObject") and check.Visible then
        local ok = pcall(function()
            local pos, size = check.AbsolutePosition, check.AbsoluteSize
            local inset = GuiService:GetGuiInset()
            local x, y = pos.X + size.X / 2 + inset.X, pos.Y + size.Y / 2 + inset.Y
            VIM:SendMouseButtonEvent(x, y, 0, true, game, 1)
            task.wait(0.02)
            VIM:SendMouseButtonEvent(x, y, 0, false, game, 1)
        end)
        if ok then return true end
    end

    return pcall(function()
        VIM:SendKeyEvent(true, Enum.KeyCode.Space, false, game)
        task.wait(0.03)
        VIM:SendKeyEvent(false, Enum.KeyCode.Space, false, game)
    end)
end

function VD.skillCheckStep()
    if not Cfg.VDAutoSkillCheck then
        lastGoalRotation = nil
        return
    end
    local line, goal = findSkillCheck()
    if not (line and goal) then
        lastGoalRotation = nil
        return
    end
    local goalRotation = goal.Rotation
    local lineRotation = line.Rotation
    local now = os.clock()
    if now - lastPress < 0.10 then return end

    local offset = (lineRotation - goalRotation) % 360
    local mode = Cfg.VDSkillMode
    local low, high
    if mode == "Normal" then
        low, high = 116, 159
    elseif mode == "Instant" then
        -- posisikan jarum di zona sukses, lalu tekan
        pcall(function() line.Rotation = goalRotation + 109 end)
        low, high = 102, 116
    else
        low, high = 102, 116
    end

    if goalRotation ~= lastGoalRotation and mode == "Instant" then
        pcall(function() line.Rotation = goalRotation + 109 end)
        offset = 109
    end
    if offset >= low and offset <= high then
        if pressSkillCheck() then
            lastPress = now
            lastGoalRotation = goalRotation
        end
    end
end

local function restoreSpeed(hum)
    local rec = speedRecords[hum]
    if not rec then return end
    pcall(function()
        -- kembalikan hanya bila nilai kita masih terpasang
        if hum and hum.Parent and rec.applied
            and math.abs(hum.WalkSpeed - rec.applied) < 0.05 then
            hum.WalkSpeed = rec.original
        end
    end)
    speedRecords[hum] = nil
end

local BLOCKED_ATTRS = {
    "IsHooked", "IsCarried", "Crouching", "IsInteracting",
    "IsRepairing", "IsHealing", "IsVaulting", "DoingAction",
}

local function isSafeMovementState(char, hum)
    if not Cfg.VDSpeedSafeMode then return false end
    if not char or not hum or hum.Health <= 0 then return true end
    for _, attributeName in ipairs(BLOCKED_ATTRS) do
        if char:GetAttribute(attributeName) == true then return true end
        if hum:GetAttribute(attributeName) == true then return true end
    end
    if hum.Health <= 50 then return true end
    return false
end

function VD.speedStep()
    local char = LP.Character
    local hum = char and char:FindFirstChildOfClass("Humanoid")
    if not hum then return end

    if not Cfg.VDSpeedBoost or isSafeMovementState(char, hum) then
        restoreSpeed(hum)
        return
    end

    local rec = speedRecords[hum]
    if not rec then
        rec = { original = hum.WalkSpeed, applied = nil }
        speedRecords[hum] = rec
    end
    local multiplier = math.clamp(tonumber(Cfg.VDSpeedMultiplier) or 0.30, 0, 2)
    local target = rec.original * (1 + multiplier)
    rec.applied = target
    if math.abs(hum.WalkSpeed - target) > 0.05 then
        pcall(function() hum.WalkSpeed = target end)
    end
end

Scheduler.add("VD skillcheck", 0.05, VD.skillCheckStep)
Scheduler.add("VD speed", 0.05, VD.speedStep)

Hub.onUnload(function()
    Cfg.VDAutoSkillCheck, Cfg.VDSpeedBoost = false, false
    for hum in pairs(speedRecords) do restoreSpeed(hum) end
    table.clear(speedRecords)
end)

return VD
end,
["features/FastVault"] = function(...)
-- Violence District: Fast Vaulting (percepat vault jendela).
-- Hasil logger: vault dijalankan CLIENT. Karakter punya atribut `vaultspeed` (default 1) yang dipakai game
-- untuk kecepatan animasi "RunningVaultAnimation"; gerakan vault ikut animasi lewat marker keyframe
-- "CFRAME;x,y,z", jadi animasi lebih cepat = vault lebih cepat.
-- Dua metode (Cfg.VDVaultMode):
--   Atribut  : atribut karakter `vaultspeed` dikali Cfg.VDVaultMult (cara bawaan game, nilai asli dipulihkan)
--   Animasi  : AnimationTrack yang namanya cocok kata kunci (Cfg.VDVaultKeys) dipercepat lewat AdjustSpeed
-- Dimatikan / unload -> nilai asli dipulihkan. Server tetap menerima remote VaultEvent/VaultComplete
-- lebih cepat dari biasanya; pakai kelipatan kecil dulu.
local Hub = ...
local Players = game:GetService("Players")
local LP = Players.LocalPlayer
local Config = Hub.use("config/Config")
local Cfg = Config.Cfg
local Util = Hub.use("core/Util")
local Scheduler = Hub.use("core/Scheduler")

local ATTR = "vaultspeed"
local FV = { runId = "rbxassetid://83873880822918", keys = {}, recent = {}, boosted = 0, status = "Mati", attr = { char = nil, orig = nil, set = nil } }
local swapped = setmetatable({}, { __mode = "k" })
local base = setmetatable({}, { __mode = "k" }) -- AnimationTrack -> kecepatan asli
local animator, conn

function FV.rebuild() FV.keys = Util.splitKeys(Cfg.VDVaultKeys) end
FV.rebuild()
Config.reg("VDVaultKeys", FV.rebuild)

function FV.matches(name)
    local l = tostring(name):lower()
    for _, k in ipairs(FV.keys) do
        if l:find(k, 1, true) then return true end
    end
    return false
end

-- catat nama animasi sekali-jalan (bukan loop) supaya tidak penuh idle/jalan
local function note(track)
    local okn, nm = pcall(function() return tostring(track.Name):lower() end)
    if okn and nm:find("runningvault", 1, true) then
        local okid, id = pcall(function() return track.Animation.AnimationId end)
        if okid and type(id) == "string" and id ~= "" then FV.runId = id end
    end
    local ok, looped = pcall(function() return track.Looped end)
    if ok and looped then return end
    local n = tostring(track.Name)
    local idx = table.find(FV.recent, n)
    if idx then table.remove(FV.recent, idx) end
    table.insert(FV.recent, 1, n)
    while #FV.recent > 8 do table.remove(FV.recent) end
end

--------------------------------------------------------
-- metode Animasi
--------------------------------------------------------
function FV.boost(track)
    if base[track] == nil then base[track] = track.Speed end
    local want = base[track] * Cfg.VDVaultMult
    if math.abs(track.Speed - want) > 0.01 then track:AdjustSpeed(want) end
end

function FV.restoreAnim()
    for track, sp in pairs(base) do
        pcall(function() track:AdjustSpeed(sp) end)
        base[track] = nil
    end
    FV.boosted = 0
end

--------------------------------------------------------
-- metode Atribut (vaultspeed)
--------------------------------------------------------
-- dipanggil berkala; nilai asli diingat, perubahan dari game (mis. perk) ikut jadi nilai asli baru
function FV.attrStep(ch)
    local st = FV.attr
    if not ch then return "Menunggu karakter" end
    if st.char ~= ch then st.char, st.orig, st.set = ch, nil, nil end
    local cur = ch:GetAttribute(ATTR)
    if type(cur) ~= "number" then return "Atribut vaultspeed tidak ada di karakter" end
    if st.set == nil or math.abs(cur - st.set) > 1e-6 then st.orig = cur end
    local want = st.orig * Cfg.VDVaultMult
    if math.abs(cur - want) > 1e-6 then ch:SetAttribute(ATTR, want) end
    st.set = want
    return ("Aktif: vaultspeed %g -> %g"):format(st.orig, want)
end

function FV.restoreAttr()
    local st = FV.attr
    local ch = st.char
    if ch and st.orig ~= nil and st.set ~= nil then
        pcall(function()
            local cur = ch:GetAttribute(ATTR)
            if type(cur) == "number" and math.abs(cur - st.set) < 1e-6 then ch:SetAttribute(ATTR, st.orig) end
        end)
    end
    st.char, st.orig, st.set = nil, nil, nil
end

function FV.restore()
    FV.restoreAnim()
    FV.restoreAttr()
end

function FV.clearRecent() FV.recent = {} end

--------------------------------------------------------
-- pemantau animasi (daftar nama + metode Animasi)
--------------------------------------------------------
local function onPlayed(track)
    note(track)
    if Cfg.VDFastVault and Cfg.VDVaultMode == "Animasi" and not (Cfg.VDVaultForce and tostring(track.Name):lower():find("walkingvault", 1, true)) and FV.matches(track.Name) then pcall(FV.boost, track) end
end

-- sambungkan ke Animator karakter saat ini (otomatis ikut respawn)
local function hook()
    local ch = LP.Character
    local hum = ch and ch:FindFirstChildOfClass("Humanoid")
    local a = hum and hum:FindFirstChildOfClass("Animator")
    if a == animator then return end
    if conn then pcall(function() conn:Disconnect() end) conn = nil end
    animator = a
    if a then conn = Hub.track(a.AnimationPlayed:Connect(onPlayed)) end
end

function FV.step()
    hook()
    if not Cfg.VDFastVault then
        if next(base) or FV.attr.char then FV.restore() end
        FV.status = "Mati"
        return
    end
    local mode = Cfg.VDVaultMode
    if mode == "Animasi" then
        FV.restoreAttr()
        if not animator then FV.status = "Menunggu karakter" return end
        local n = 0
        -- terapkan ulang tiap 0.05 dtk: game kadang menulis ulang kecepatan track
        for _, track in ipairs(animator:GetPlayingAnimationTracks()) do
            if FV.matches(track.Name) and not (Cfg.VDVaultForce and tostring(track.Name):lower():find("walkingvault", 1, true)) then
                pcall(FV.boost, track)
                n += 1
            end
        end
        FV.boosted = n
        FV.status = n > 0 and ("Aktif: %d animasi dipercepat x%g"):format(n, Cfg.VDVaultMult) or "Siaga (menunggu vault)"
    else
        FV.restoreAnim()
        local ok, msg = pcall(FV.attrStep, LP.Character)
        FV.status = ok and msg or ("Error: " .. tostring(msg))
    end
end

--------------------------------------------------------
-- Paksa tier "fast" (Cfg.VDVaultForce)
-- Dari log: client memilih tier ("fast" bila lari kencang, "medium" bila pelan) lalu mengirimnya di
-- argumen ke-5 VaultEvent:FireServer(trigger, true, uuid, char, tier). Di sini argumen itu diganti "fast"
-- dan animasi "WalkingVault" disamakan durasinya dengan vault fast asli (0.50 dtk / pengali).
-- Server bisa saja memvalidasi tier sendiri; bila vault jadi macet/ditolak, matikan opsi ini.
--------------------------------------------------------
local RUN_LEN = 0.50 -- panjang RunningVaultAnimation2 (vault fast asli) pada kecepatan 1x
local dead = false
FV.forced = 0

if hookmetamethod and newcclosure and getnamecallmethod then
    local old
    local ok = pcall(function()
        old = hookmetamethod(game, "__namecall", newcclosure(function(self, ...)
            if dead or not (Cfg.VDFastVault and Cfg.VDVaultForce) then return old(self, ...) end
            if getnamecallmethod() ~= "FireServer" then return old(self, ...) end
            local a2, a5 = select(2, ...), select(5, ...)
            if a2 == true and type(a5) == "string" and a5 ~= "fast" and self.Name == "VaultEvent" then
                local args = table.pack(...)
                args[5] = "fast"
                FV.forced += 1
                task.defer(function()
                    pcall(function() LP.Character:SetAttribute("VaultTier", "fast") end)
                end)
                return old(self, table.unpack(args, 1, args.n))
            end
            return old(self, ...)
        end))
    end)
    FV.hooked = ok and old ~= nil
else
    FV.hooked = false
end

-- samakan durasi animasi walking-vault dengan fast (dipanggil tiap step)
function FV.equalize()
    if not (animator and Cfg.VDVaultForce) then return end
    for _, track in ipairs(animator:GetPlayingAnimationTracks()) do
        if tostring(track.Name):lower():find("walkingvault", 1, true) and track.Length > 0 then
            if base[track] == nil then base[track] = track.Speed end
            -- vault fast asli = 0.50 dtk / pengali; samakan durasi walking-vault dengan itu
            local want = math.min(track.Length / (RUN_LEN / math.max(Cfg.VDVaultMult, 1)), 6)
            if math.abs(track.Speed - want) > 0.01 then track:AdjustSpeed(want) end
            if Cfg.VDVaultAnim and not swapped[track] then FV.swapVisual(track) end
        end
    end
end

-- Gerakan (marker CFRAME) tetap dijalankan animasi walking milik game, tapi tampilannya diganti animasi
-- RunningVault (vault fast asli): walking dibuat nyaris tak terlihat, running dimainkan di atasnya.
function FV.swapVisual(walk)
    swapped[walk] = true
    local ok = pcall(function()
        local a = Instance.new("Animation")
        a.AnimationId = FV.runId
        local rt = animator:LoadAnimation(a)
        rt.Priority = Enum.AnimationPriority.Action
        rt.Looped = false
        walk:AdjustWeight(0.001, 0)
        rt:Play(0, 1, math.max(Cfg.VDVaultMult, 1))
        local c
        c = walk.Stopped:Connect(function()
            pcall(function() rt:Stop(0) rt:Destroy() end)
            if c then c:Disconnect() end
        end)
    end)
    if not ok then swapped[walk] = true end
end

Scheduler.add("Fast vault", 0.05, function()
    FV.step()
    if Cfg.VDFastVault and Cfg.VDVaultForce then pcall(FV.equalize) end
end)
Hub.onUnload(function() dead = true FV.restore() end)

return FV
end,
["features/Movement"] = function(...)
-- Gerak: Speed, Noclip, Fly.
-- Speed otomatis ditahan (kembali ke nilai default game) saat knockdown / digendong / digantung / mati.
local Hub = ...
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local UIS = game:GetService("UserInputService")
local LP = Players.LocalPlayer
local Cfg = Hub.use("config/Config").Cfg
local Scheduler = Hub.use("core/Scheduler")

local Move = { ws = nil, applied = nil, bv = nil, bg = nil, parts = {}, t = 0, status = "Mati" }

local function myHum()
    return LP.Character and LP.Character:FindFirstChildOfClass("Humanoid")
end

function Move.blockedReason()
    local ch, h = LP.Character, myHum()
    if not ch or not h or h.Health <= 0 then return "mati" end
    for _, obj in ipairs({ ch, LP }) do
        if obj:GetAttribute("Knocked") == true then return "knockdown" end
        if obj:GetAttribute("IsCarried") == true then return "digendong" end
        if obj:GetAttribute("IsHooked") == true then return "digantung" end
        if obj:GetAttribute("IsDead") == true then return "mati" end
    end
    return nil
end

function Move.stopFly()
    if Move.bv then Move.bv:Destroy() Move.bv = nil end
    if Move.bg then Move.bg:Destroy() Move.bg = nil end
    local h = myHum()
    if h then h.PlatformStand = false end
end

function Move.releaseSpeed(h)
    if Move.applied then
        -- kalau game sudah menulis nilainya sendiri (beda dari nilai kita), biarkan; kalau tidak, kembalikan default terakhir
        if h and math.abs(h.WalkSpeed - Move.applied) <= 0.05 and Move.ws then
            h.WalkSpeed = Move.ws
        end
        Move.applied = nil
    end
end

function Move.stopAll()
    Cfg.Speed, Cfg.Noclip, Cfg.Fly = false, false, false
    Move.stopFly()
    Move.releaseSpeed(myHum())
end

function Move.tick()
    local ch, h = LP.Character, myHum()
    local root = ch and ch:FindFirstChild("HumanoidRootPart")
    if not (h and root) then return end
    local reason = Cfg.SpeedSafe and Move.blockedReason() or nil

    -- SPEED
    if Cfg.Speed and not reason then
        if not Move.applied then
            Move.ws = h.WalkSpeed
        elseif math.abs(h.WalkSpeed - Move.applied) > 0.05 then
            Move.ws = h.WalkSpeed -- game menulis nilai baru: itu jadi "default" terbaru
        end
        Move.applied = Cfg.SpeedVal
        h.WalkSpeed = Cfg.SpeedVal
        Move.status = "Aktif (" .. Cfg.SpeedVal .. ")"
    else
        Move.releaseSpeed(h)
        Move.status = Cfg.Speed and ("Ditahan: " .. (reason or "-") .. " (speed default)") or "Mati"
    end

    -- FLY
    if Cfg.Fly and not reason then
        if not (Move.bv and Move.bv.Parent) then
            Move.bv = Instance.new("BodyVelocity")
            Move.bv.MaxForce = Vector3.new(1e9, 1e9, 1e9)
            Move.bv.Velocity = Vector3.zero
            Move.bv.Parent = root
            Move.bg = Instance.new("BodyGyro")
            Move.bg.MaxTorque = Vector3.new(1e9, 1e9, 1e9)
            Move.bg.P = 1e4
            Move.bg.Parent = root
        end
        h.PlatformStand = true
        local cam = workspace.CurrentCamera
        local md = h.MoveDirection
        local vel = md * Cfg.FlySpeed
        if md.Magnitude > 0 then
            local flat = Vector3.new(cam.CFrame.LookVector.X, 0, cam.CFrame.LookVector.Z)
            if flat.Magnitude > 0 then
                local fwd = md:Dot(flat.Unit)
                vel += Vector3.new(0, cam.CFrame.LookVector.Y * Cfg.FlySpeed * math.max(fwd, 0), 0)
            end
        end
        if UIS:IsKeyDown(Enum.KeyCode.Space) then vel += Vector3.new(0, Cfg.FlySpeed, 0) end
        if UIS:IsKeyDown(Enum.KeyCode.LeftControl) then vel -= Vector3.new(0, Cfg.FlySpeed, 0) end
        Move.bv.Velocity = vel
        Move.bg.CFrame = cam.CFrame
    elseif Move.bv then
        Move.stopFly()
    end
end

-- noclip: matikan CanCollide seluruh bagian karakter (daftar bagian di-refresh tiap 0.5 detik)
Hub.track(RunService.Stepped:Connect(function(_, dt)
    if Hub.Dead then return end
    local ch = LP.Character
    if not ch or not (Cfg.Noclip or Cfg.Fly) then return end
    Move.t += dt
    if Move.t >= 0.5 or #Move.parts == 0 then
        Move.t = 0
        Move.parts = {}
        for _, d in ipairs(ch:GetDescendants()) do
            if d:IsA("BasePart") then Move.parts[#Move.parts + 1] = d end
        end
    end
    for _, p in ipairs(Move.parts) do
        if p.Parent and p.CanCollide then p.CanCollide = false end
    end
end))

Scheduler.add("Gerak", 0, Move.tick)
Hub.onUnload(Move.stopAll)

return Move
end,
["features/SkillScan"] = function(...)
-- Scanner skill check: rekam GUI yang muncul, rotasi yang berubah (jarum), input yang kamu tekan,
-- dan remote yang dikirim selama beberapa detik. Hasil disalin ke clipboard untuk dianalisis.
--   SkillScan.start(detik, callback(teks))
local Hub = ...
local Players = game:GetService("Players")
local UIS = game:GetService("UserInputService")
local RunService = game:GetService("RunService")
local LP = Players.LocalPlayer
local Util = Hub.use("core/Util")

local Scan = { active = false }
local remoteLog = nil -- diisi saat scan aktif
local hooked = false

local function shownChain(d)
    local p = d
    while p and not p:IsA("PlayerGui") do
        if p:IsA("GuiObject") and not p.Visible then return false end
        if p:IsA("ScreenGui") and not p.Enabled then return false end
        p = p.Parent
    end
    return true
end

local function hookRemotes()
    if hooked or not (hookmetamethod and newcclosure and getnamecallmethod) then return end
    hooked = true
    local old
    -- jangan memanggil method Instance (mis. GetFullName) di dalam hook: bisa merusak panggilan remote asli.
    -- Pencatatan dijadwalkan lewat task.defer setelah panggilan asli diteruskan.
    old = hookmetamethod(game, "__namecall", newcclosure(function(self, ...)
        if not remoteLog or Hub.Dead then return old(self, ...) end
        local m = getnamecallmethod()
        if m == "FireServer" or m == "InvokeServer" then
            local sf, args = self, table.pack(...)
            task.defer(function()
                if not remoteLog then return end
                local parts = {}
                for i = 1, math.min(args.n, 6) do parts[#parts + 1] = typeof(args[i]) .. ":" .. tostring(args[i]):sub(1, 30) end
                remoteLog[#remoteLog + 1] = ("%s:%s(%s)"):format(Util.pathOf(sf), m, table.concat(parts, ", "))
            end)
        end
        return old(self, ...)
    end))
end

function Scan.start(seconds, done)
    if Scan.active then return end
    local pg = LP:FindFirstChildOfClass("PlayerGui")
    if not pg then done("PlayerGui tidak ditemukan") return end
    Scan.active = true
    hookRemotes()
    remoteLog = {}

    -- snapshot: GUI yang SUDAH tampil sebelum scan tidak dilaporkan
    local before = {}
    for _, d in ipairs(pg:GetDescendants()) do
        if d:IsA("GuiObject") and shownChain(d) then before[d] = true end
    end

    local seen, inputs = {}, {}
    local t0 = os.clock()
    local inConn = UIS.InputBegan:Connect(function(i, gpe)
        inputs[#inputs + 1] = ("%.2fs %s %s gpe=%s"):format(os.clock() - t0, tostring(i.UserInputType.Name), tostring(i.KeyCode.Name), tostring(gpe))
    end)

    local acc = 0
    local conn
    conn = RunService.Heartbeat:Connect(function(dt)
        if Hub.Dead then conn:Disconnect() inConn:Disconnect() Scan.active = false return end
        acc += dt
        if acc < 0.05 then return end
        acc = 0
        for _, d in ipairs(pg:GetDescendants()) do
            if d:IsA("GuiObject") and not before[d] and shownChain(d) then
                local r = seen[d]
                if not r then
                    r = { t = os.clock() - t0, rot = d.Rotation, rotMin = d.Rotation, rotMax = d.Rotation, changes = 0 }
                    seen[d] = r
                end
                if math.abs(d.Rotation - r.rot) > 0.01 then
                    r.changes += 1
                    r.rot = d.Rotation
                    r.rotMin, r.rotMax = math.min(r.rotMin, d.Rotation), math.max(r.rotMax, d.Rotation)
                end
            end
        end
        if os.clock() - t0 >= seconds then
            conn:Disconnect()
            inConn:Disconnect()
            Scan.active = false

            local out = { ("== SKILLCHECK SCAN (%ds) =="):format(seconds), "-- GUI baru yang tampil --" }
            local list = {}
            for d, r in pairs(seen) do list[#list + 1] = { d = d, r = r } end
            table.sort(list, function(a, b) return a.r.t < b.r.t end)
            for i, e in ipairs(list) do
                if i > 60 then out[#out + 1] = "..." break end
                local d, r = e.d, e.r
                local extra = ""
                if d:IsA("ImageLabel") or d:IsA("ImageButton") then extra = " img=" .. tostring(d.Image):sub(1, 40) end
                if d:IsA("TextLabel") or d:IsA("TextButton") then extra = " text=" .. tostring(d.Text):sub(1, 30) end
                local attrs = {}
                for k, v in pairs(d:GetAttributes()) do attrs[#attrs + 1] = k .. "=" .. tostring(v) end
                out[#out + 1] = ("[%.2fs] %s <%s> pos=(%d,%d) size=(%d,%d) rot=%.1f rotRange=%.1f..%.1f rotChanges=%d bg=%s%s%s"):format(
                    r.t, Util.pathOf(d), d.ClassName, d.AbsolutePosition.X, d.AbsolutePosition.Y,
                    d.AbsoluteSize.X, d.AbsoluteSize.Y, d.Rotation, r.rotMin, r.rotMax, r.changes,
                    Util.hex(d.BackgroundColor3), extra, #attrs > 0 and (" attrs{" .. table.concat(attrs, ",") .. "}") or "")
            end
            if #list == 0 then out[#out + 1] = "(tidak ada GUI baru; skill check mungkin tidak muncul selama scan)" end
            out[#out + 1] = "-- Input yang kamu tekan --"
            for _, s in ipairs(inputs) do out[#out + 1] = s end
            if #inputs == 0 then out[#out + 1] = "(tidak ada)" end
            out[#out + 1] = "-- Remote dikirim --"
            for i, s in ipairs(remoteLog or {}) do
                if i > 40 then out[#out + 1] = "..." break end
                out[#out + 1] = s
            end
            if not hooked then out[#out + 1] = "(hook remote tidak didukung executor)" end
            remoteLog = nil
            done(table.concat(out, "\n"))
        end
    end)
end

return Scan
end,
["features/World"] = function(...)
-- Dunia: fullbright, tanpa kabut, matikan PostEffect, kunci jam, dan mode HD grafis.
-- World.apply() tiap frame; World.fxScan() & World.applyHD() tiap 0.5 detik.
-- Nilai asli dipulihkan saat fitur dimatikan. Semua efek hanya di sisi klien (visual).
local Hub = ...
local Lighting = game:GetService("Lighting")
local Config = Hub.use("config/Config")
local Cfg = Config.Cfg
local Scheduler = Hub.use("core/Scheduler")

local World = { saved = nil, fx = {} }

local function restoreFx(onlyKind)
    for inst, d in pairs(World.fx) do
        if not onlyKind or d.kind == onlyKind then
            if inst.Parent then
                pcall(function()
                    if d.kind == "atm" then inst.Density, inst.Haze = d.Density, d.Haze
                    else inst.Enabled = d.Enabled end
                end)
            end
            World.fx[inst] = nil
        end
    end
end

function World.apply()
    if not Cfg.Fullbright then
        if World.saved then
            for k, v in pairs(World.saved) do pcall(function() Lighting[k] = v end) end
            World.saved = nil
            restoreFx()
        end
        return
    end
    if not World.saved then
        World.saved = {
            Brightness = Lighting.Brightness, Ambient = Lighting.Ambient,
            OutdoorAmbient = Lighting.OutdoorAmbient, ClockTime = Lighting.ClockTime,
            FogEnd = Lighting.FogEnd, FogStart = Lighting.FogStart,
        }
    end
    Lighting.Brightness = Cfg.Bright
    Lighting.Ambient = Cfg.AmbientColor
    Lighting.OutdoorAmbient = Cfg.AmbientColor
    if Cfg.ForceTime then Lighting.ClockTime = Cfg.Time end
    if Cfg.NoFog then Lighting.FogEnd, Lighting.FogStart = 1e6, 1e5 end
end

function World.fxScan()
    if not Cfg.Fullbright then return end
    if not Cfg.NoFog then restoreFx("atm") end
    if not Cfg.NoFx then restoreFx("fx") end
    for _, e in ipairs(Lighting:GetChildren()) do
        if e:IsA("Atmosphere") and Cfg.NoFog then
            if not World.fx[e] then World.fx[e] = { kind = "atm", Density = e.Density, Haze = e.Haze } end
            e.Density, e.Haze = 0, 0
        elseif e:IsA("PostEffect") and Cfg.NoFx and e.Name:sub(1, 5) ~= "TOFHD" then
            -- efek milik mode HD (nama "TOFHD_*") tidak ikut dimatikan
            if not World.fx[e] then World.fx[e] = { kind = "fx", Enabled = e.Enabled } end
            e.Enabled = false
        end
    end
end

--------------------------------------------------------
-- Mode HD: koreksi warna (kontras/saturasi), bloom, sun rays, bayangan tajam,
-- kualitas render maksimum, detail mesh maksimum, dan (opsional) Future lighting.
--------------------------------------------------------
World.PRESETS = {
    Sedang = { HDContrast = 6, HDSaturation = 8, HDBloom = 15 },
    Tinggi = { HDContrast = 12, HDSaturation = 14, HDBloom = 25 },
    Ultra = { HDContrast = 20, HDSaturation = 20, HDBloom = 40 },
}
World.PRESET_NAMES = { "Sedang", "Tinggi", "Ultra" }
local SUN = { Sedang = 0, Tinggi = 0.05, Ultra = 0.1 }

function World.applyPreset(name)
    local p = World.PRESETS[name]
    if not p then return end
    for k, v in pairs(p) do Config.set(k, v) end
end

local HD = {
    saved = nil, meshOn = false, futureOn = false, scanTok = 0,
    mesh = setmetatable({}, { __mode = "k" }), -- MeshPart -> RenderFidelity asli
}
World.hd = HD
local LIGHT_PROPS = { "GlobalShadows", "ShadowSoftness", "EnvironmentSpecularScale", "EnvironmentDiffuseScale" }

local function ensureFx(class, name)
    local o = Lighting:FindFirstChild(name)
    if o and not o:IsA(class) then o:Destroy() o = nil end
    if not o then
        o = Instance.new(class)
        o.Name = name
        o.Parent = Lighting
    end
    return o
end

local function rendering()
    local ok, r = pcall(function() return settings().Rendering end)
    return ok and r or nil
end

local function meshHD(d)
    if HD.mesh[d] == nil then
        local ok, v = pcall(function() return d.RenderFidelity end)
        if not ok then return end
        HD.mesh[d] = v
    end
    pcall(function() d.RenderFidelity = Enum.RenderFidelity.Precise end)
end

local function setMesh(on)
    HD.scanTok += 1
    local tok = HD.scanTok
    HD.meshOn = on
    if on then
        task.spawn(function()
            local n = 0
            for _, d in ipairs(workspace:GetDescendants()) do
                if tok ~= HD.scanTok or Hub.Dead then return end
                if d:IsA("MeshPart") then meshHD(d) end
                n += 1
                if n % 1500 == 0 then task.wait() end
            end
        end)
    else
        for part, fid in pairs(HD.mesh) do
            pcall(function() if part.Parent then part.RenderFidelity = fid end end)
            HD.mesh[part] = nil
        end
    end
end

local function setFuture(on)
    HD.futureOn = on
    if not sethiddenproperty then return end
    pcall(function()
        if on then
            sethiddenproperty(Lighting, "Technology", Enum.Technology.Future)
        elseif HD.saved and HD.saved.Tech ~= nil then
            sethiddenproperty(Lighting, "Technology", HD.saved.Tech)
        end
    end)
end

function World.hdOff()
    local s = HD.saved
    for _, name in ipairs({ "TOFHD_CC", "TOFHD_Bloom", "TOFHD_Sun" }) do
        local o = Lighting:FindFirstChild(name)
        if o then pcall(function() o:Destroy() end) end
    end
    if HD.meshOn then setMesh(false) end
    if HD.futureOn then setFuture(false) end
    if s then
        for _, k in ipairs(LIGHT_PROPS) do
            if s[k] ~= nil then pcall(function() Lighting[k] = s[k] end) end
        end
        local r = rendering()
        if r and s.Quality ~= nil then pcall(function() r.QualityLevel = s.Quality end) end
    end
    HD.saved = nil
end

function World.applyHD()
    if not Cfg.HD then
        if HD.saved then World.hdOff() end
        return
    end
    if not HD.saved then
        local s = {}
        for _, k in ipairs(LIGHT_PROPS) do pcall(function() s[k] = Lighting[k] end) end
        local r = rendering()
        if r then pcall(function() s.Quality = r.QualityLevel end) end
        if gethiddenproperty then pcall(function() s.Tech = gethiddenproperty(Lighting, "Technology") end) end
        HD.saved = s
    end

    -- koreksi warna + bloom + sun rays (dibuat ulang bila game menghapusnya)
    local cc = ensureFx("ColorCorrectionEffect", "TOFHD_CC")
    cc.Contrast = Cfg.HDContrast / 100
    cc.Saturation = Cfg.HDSaturation / 100
    local bloom = ensureFx("BloomEffect", "TOFHD_Bloom")
    bloom.Intensity = Cfg.HDBloom / 100
    bloom.Size = 20
    bloom.Threshold = 1.1
    local sunI = SUN[Cfg.HDPreset] or 0
    local sun = ensureFx("SunRaysEffect", "TOFHD_Sun")
    sun.Enabled = sunI > 0
    sun.Intensity, sun.Spread = sunI, 0.6

    -- bayangan tajam + pantulan lingkungan penuh
    pcall(function()
        Lighting.GlobalShadows = Cfg.HDShadows
        Lighting.ShadowSoftness = 0.1
        Lighting.EnvironmentSpecularScale = 1
        Lighting.EnvironmentDiffuseScale = 1
    end)

    -- kualitas render
    local r = rendering()
    if r and HD.saved.Quality ~= nil then
        pcall(function()
            local want = Cfg.HDQuality and Enum.QualityLevel.Level21 or HD.saved.Quality
            if r.QualityLevel ~= want then r.QualityLevel = want end
        end)
    end

    if Cfg.HDMesh ~= HD.meshOn then setMesh(Cfg.HDMesh) end
    if Cfg.HDFuture ~= HD.futureOn then setFuture(Cfg.HDFuture) end
end

-- MeshPart baru ikut detail maksimum selama opsinya aktif
Hub.track(workspace.DescendantAdded:Connect(function(d)
    if HD.meshOn and Cfg.HD and d:IsA("MeshPart") then meshHD(d) end
end))

-- respon instan saat slider/toggle HD diubah (selain tick 0.5 detik)
for _, k in ipairs({ "HD", "HDPreset", "HDContrast", "HDSaturation", "HDBloom", "HDShadows", "HDQuality", "HDMesh", "HDFuture" }) do
    Config.reg(k, function() World.applyHD() end)
end

Scheduler.add("Dunia fx", 0.5, World.fxScan)
Scheduler.add("Dunia HD", 0.5, World.applyHD)
Scheduler.add("Dunia", 0, World.apply)

Hub.onUnload(function()
    Cfg.Fullbright = false
    Cfg.HD = false
    pcall(World.apply)
    pcall(World.hdOff)
end)

return World
end,
["ui/CategoryGroup"] = function(...)
-- Grup pengaturan standar untuk satu kategori ESP (dipakai tab ESP untuk semua kategori):
-- Tampilkan, Chams, Label, Jarak maksimal, Warna, (+ kata kunci nama untuk objek).
--   CategoryGroup(page, kategori, extra?)   extra(g) = tambahan kontrol khusus
-- Catatan: toggle "Label" hanya berlaku bila saklar utama "Label semua ESP" aktif.
local Hub = ...
local Objects = Hub.use("esp/Objects")

return function(page, c, extra)
    local g = page:Group(c.name, c.col, c.on)
    g:Toggle("Tampilkan", c.on)
    g:Toggle("Chams (outline + isi)", c.chams)
    g:Toggle("Label", c.label)
    g:Slider("Jarak maksimal", c.dist, 50, 5000, 50, " m")
    g:Color("Warna", c.col)
    if c.keyCfg then g:Input("Kata kunci nama", c.keyCfg, c.keyDef, Objects.rescan) end
    if extra then extra(g) end
end
end,
["ui/Controls"] = function(...)
-- Kontrol interaktif yang terhubung ke Cfg: Toggle, Slider, Choice, Input, Color, Group.
-- Menambah method ke kelas Page; tab cukup `local Page = Hub.use("ui/Controls")`.
-- Kontrol baru = tambah satu `function Page:NamaBaru(...)` di sini.
local Hub = ...
local Config = Hub.use("config/Config")
local Cfg, reg, setCfg = Config.Cfg, Config.reg, Config.set
local Util = Hub.use("core/Util")
local Kit = Hub.use("ui/Kit")
local Page = Hub.use("ui/Page")
local T, new, corner, lbl, tween = Kit.T, Kit.new, Kit.corner, Kit.lbl, Kit.tween
local hoverFx, onAccent, isPress, Drag = Kit.hoverFx, Kit.onAccent, Kit.isPress, Kit.Drag
local spring = Kit.spring

--------------------------------------------------------
-- Toggle
--------------------------------------------------------
function Page:Toggle(label, key)
    local f = self:card(34)
    local base = self:base()
    local l = lbl(f, label, 12, T.text)
    l.Position, l.Size = UDim2.fromOffset(12, 0), UDim2.new(1, -66, 1, 0)
    local pill = new("Frame", {
        AnchorPoint = Vector2.new(1, 0.5), Position = UDim2.new(1, -12, 0.5, 0),
        Size = UDim2.fromOffset(36, 20), BackgroundColor3 = T.track, BorderSizePixel = 0,
    }, f)
    corner(pill, 10)
    local dot = new("Frame", {
        AnchorPoint = Vector2.new(0, 0.5), Position = UDim2.new(0, 3, 0.5, 0),
        Size = UDim2.fromOffset(14, 14), BackgroundColor3 = T.muted, BorderSizePixel = 0,
    }, pill)
    corner(dot, 7)
    local btn = new("TextButton", { Size = UDim2.new(1, 0, 1, 0), BackgroundTransparency = 1, Text = "" }, f)
    local function paint()
        local on = Cfg[key]
        -- bulatan membal melewati ujung lalu kembali (ala blok Mario)
        spring(dot, { Position = on and UDim2.new(1, -17, 0.5, 0) or UDim2.new(0, 3, 0.5, 0) }, 0.34)
        tween(dot, { BackgroundColor3 = on and T.text or T.muted })
        tween(pill, { BackgroundColor3 = on and Cfg.Accent or T.track })
    end
    reg(key, paint)
    onAccent(paint)
    hoverFx(f, btn, base)
    btn.Activated:Connect(function()
        Kit.pop(pill, 0.86)
        setCfg(key, not Cfg[key])
    end)
end

--------------------------------------------------------
-- Slider (nilai bisa diketik) — juga dipakai oleh Color
--------------------------------------------------------
local function makeSlider(parent, order, label, min, max, step, value, suffix, onSet, bg)
    local base = bg or T.surface
    local f = new("Frame", { Size = UDim2.new(1, 0, 0, 44), BackgroundColor3 = base, BorderSizePixel = 0, LayoutOrder = order }, parent)
    corner(f, 8)
    local l = lbl(f, label, 12, T.text)
    l.Position, l.Size = UDim2.fromOffset(12, 6), UDim2.new(0.55, -12, 0, 18)
    -- nilai bisa DIKETIK dengan keyboard (tap angka, ketik, Enter)
    local v = new("TextBox", {
        AnchorPoint = Vector2.new(1, 0), Position = UDim2.new(1, -10, 0, 5), Size = UDim2.fromOffset(78, 20),
        BackgroundColor3 = T.track, BackgroundTransparency = 0.5, BorderSizePixel = 0,
        Font = Enum.Font.GothamBold, TextSize = 11, TextColor3 = T.text, Text = "",
        ClearTextOnFocus = false, TextXAlignment = Enum.TextXAlignment.Center,
    }, f)
    corner(v, 5)
    local tr = new("Frame", { Position = UDim2.fromOffset(12, 32), Size = UDim2.new(1, -24, 0, 4), BackgroundColor3 = T.track, BorderSizePixel = 0 }, f)
    corner(tr, 2)
    local fill = new("Frame", { Size = UDim2.new(0, 0, 1, 0), BackgroundColor3 = Cfg.Accent, BorderSizePixel = 0 }, tr)
    corner(fill, 2)
    local knob = new("Frame", {
        AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(0, 0, 0.5, 0),
        Size = UDim2.fromOffset(12, 12), BackgroundColor3 = T.text, BorderSizePixel = 0, ZIndex = 2,
    }, tr)
    corner(knob, 6)
    onAccent(function() fill.BackgroundColor3 = Cfg.Accent end)
    local hit = new("TextButton", { Position = UDim2.fromOffset(6, 22), Size = UDim2.new(1, -12, 0, 22), BackgroundTransparency = 1, Text = "" }, f)

    local S = { value = value }
    local function display() v.Text = ("%g"):format(S.value) .. (suffix or "") end
    function S.set(x, silent)
        x = math.clamp(x, min, max)
        x = math.clamp(min + math.floor((x - min) / step + 0.5) * step, min, max)
        S.value = x
        local a = (x - min) / (max - min)
        fill.Size = UDim2.new(a, 0, 1, 0)
        knob.Position = UDim2.new(a, 0, 0.5, 0)
        if not v:IsFocused() then display() end
        if not silent and onSet then onSet(x) end
    end

    v.Focused:Connect(function()
        v.Text = ("%g"):format(S.value)
        tween(v, { BackgroundTransparency = 0, BackgroundColor3 = T.steel })
    end)
    v.FocusLost:Connect(function()
        tween(v, { BackgroundTransparency = 0.5, BackgroundColor3 = T.track })
        local raw = v.Text:gsub(",", "."):gsub("[^%d%.%-]", "")
        local n = tonumber(raw)
        if n then S.set(n) else display() end
        display()
    end)

    hoverFx(f, f, base)
    hit.MouseEnter:Connect(function() spring(knob, { Size = UDim2.fromOffset(16, 16) }, 0.25) end)
    hit.MouseLeave:Connect(function() if not Drag.fn then spring(knob, { Size = UDim2.fromOffset(12, 12) }, 0.25) end end)
    hit.InputBegan:Connect(function(i)
        if not isPress(i) then return end
        local sf = f:FindFirstAncestorOfClass("ScrollingFrame")
        if sf then sf.ScrollingEnabled = false end
        local function upd(pos)
            local a = math.clamp((pos.X - tr.AbsolutePosition.X) / math.max(tr.AbsoluteSize.X, 1), 0, 1)
            S.set(min + a * (max - min))
        end
        upd(i.Position)
        Drag.fn = upd
        Drag.done = function()
            if sf then sf.ScrollingEnabled = true end
            spring(knob, { Size = UDim2.fromOffset(12, 12) }, 0.3)
        end
    end)
    S.set(value, true)
    display()
    return S
end

function Page:Slider(label, key, min, max, step, suffix)
    local S
    S = makeSlider(self.sf, self:next(), label, min, max, step, Cfg[key], suffix, function(x) setCfg(key, x) end, self:base())
    reg(key, function() S.set(Cfg[key], true) end)
end

--------------------------------------------------------
-- Choice (tap untuk ganti opsi berikutnya)
--------------------------------------------------------
function Page:Choice(label, key, options, onSet)
    local f = self:card(34)
    local l = lbl(f, label, 12, T.text)
    l.Position, l.Size = UDim2.fromOffset(12, 0), UDim2.new(0.45, -12, 1, 0)
    local inner = self:inner()
    local b = new("TextButton", {
        AnchorPoint = Vector2.new(1, 0.5), Position = UDim2.new(1, -10, 0.5, 0), Size = UDim2.new(0.55, -14, 0, 24),
        BackgroundColor3 = inner, BorderSizePixel = 0, AutoButtonColor = false,
        Text = "", TextSize = 11, Font = Enum.Font.GothamBold, TextColor3 = T.text,
    }, f)
    corner(b, 6)
    hoverFx(b, b, inner)
    local function paint() b.Text = tostring(Cfg[key]) end
    reg(key, paint)
    paint()
    b.Activated:Connect(function()
        local idx = table.find(options, Cfg[key]) or 0
        setCfg(key, options[idx % #options + 1])
        Kit.pop(b, 0.9)
        if onSet then onSet(Cfg[key]) end
    end)
end

--------------------------------------------------------
-- Input teks
--------------------------------------------------------
function Page:Input(label, key, placeholder, onSet)
    local f = self:card(34)
    local l = lbl(f, label, 12, T.text)
    l.Position, l.Size = UDim2.fromOffset(12, 0), UDim2.new(0.35, -12, 1, 0)
    local inner = self:inner()
    local tb = new("TextBox", {
        AnchorPoint = Vector2.new(1, 0.5), Position = UDim2.new(1, -10, 0.5, 0), Size = UDim2.new(0.65, -14, 0, 24),
        BackgroundColor3 = inner, BorderSizePixel = 0, Font = Enum.Font.Gotham, TextSize = 11, TextColor3 = T.text,
        PlaceholderText = placeholder or "", PlaceholderColor3 = T.muted, ClearTextOnFocus = false,
        Text = tostring(Cfg[key]), TextTruncate = Enum.TextTruncate.AtEnd,
    }, f)
    corner(tb, 6)
    hoverFx(tb, tb, inner)
    reg(key, function() tb.Text = tostring(Cfg[key]) end)
    tb.FocusLost:Connect(function()
        setCfg(key, tb.Text)
        if onSet then onSet() end
    end)
end

--------------------------------------------------------
-- Color picker (slider RGB + hex + preset)
--------------------------------------------------------
local PRESETS = {
    Color3.fromRGB(235, 50, 50), Color3.fromRGB(255, 150, 40), Color3.fromRGB(255, 220, 60),
    Color3.fromRGB(80, 220, 110), Color3.fromRGB(60, 210, 230), Color3.fromRGB(110, 130, 255),
    Color3.fromRGB(124, 106, 255), Color3.fromRGB(255, 110, 190), Color3.fromRGB(255, 255, 255),
}

function Page:Color(label, key)
    local base = self:base()
    local inner = self:inner()
    local wrap = new("Frame", {
        Size = UDim2.new(1, 0, 0, 0), AutomaticSize = Enum.AutomaticSize.Y,
        BackgroundColor3 = base, BorderSizePixel = 0, LayoutOrder = self:next(),
    }, self.sf)
    corner(wrap, 8)
    new("UIListLayout", { SortOrder = Enum.SortOrder.LayoutOrder, Padding = UDim.new(0, 4) }, wrap)

    local head = new("TextButton", {
        Size = UDim2.new(1, 0, 0, 34), BackgroundColor3 = base, BorderSizePixel = 0, AutoButtonColor = false, Text = "", LayoutOrder = 1,
    }, wrap)
    corner(head, 8)
    hoverFx(head, head, base)
    local l = lbl(head, label, 12, T.text)
    l.Position, l.Size = UDim2.fromOffset(12, 0), UDim2.new(1, -112, 1, 0)
    local swatch = new("Frame", {
        AnchorPoint = Vector2.new(1, 0.5), Position = UDim2.new(1, -12, 0.5, 0),
        Size = UDim2.fromOffset(28, 18), BackgroundColor3 = Cfg[key], BorderSizePixel = 0,
    }, head)
    corner(swatch, 5)
    new("UIStroke", { Color = T.stroke, ApplyStrokeMode = Enum.ApplyStrokeMode.Border }, swatch)
    local hexLbl = lbl(head, "", 10, T.muted, Enum.Font.Code, Enum.TextXAlignment.Right)
    hexLbl.AnchorPoint, hexLbl.Position, hexLbl.Size = Vector2.new(1, 0.5), UDim2.new(1, -46, 0.5, 0), UDim2.fromOffset(60, 16)

    local panelF = new("Frame", {
        Size = UDim2.new(1, 0, 0, 0), AutomaticSize = Enum.AutomaticSize.Y,
        BackgroundTransparency = 1, Visible = false, LayoutOrder = 2,
    }, wrap)
    new("UIListLayout", { SortOrder = Enum.SortOrder.LayoutOrder, Padding = UDim.new(0, 4) }, panelF)
    new("UIPadding", { PaddingLeft = UDim.new(0, 6), PaddingRight = UDim.new(0, 6), PaddingBottom = UDim.new(0, 8) }, panelF)

    local rS, gS, bS
    local function fromSliders() setCfg(key, Color3.fromRGB(rS.value, gS.value, bS.value)) end
    local c0 = Cfg[key]
    rS = makeSlider(panelF, 1, "Merah", 0, 255, 1, c0.R * 255, "", fromSliders, inner)
    gS = makeSlider(panelF, 2, "Hijau", 0, 255, 1, c0.G * 255, "", fromSliders, inner)
    bS = makeSlider(panelF, 3, "Biru", 0, 255, 1, c0.B * 255, "", fromSliders, inner)

    local hexBox = new("TextBox", {
        Size = UDim2.new(1, 0, 0, 28), BackgroundColor3 = inner, BorderSizePixel = 0, LayoutOrder = 4,
        Font = Enum.Font.Code, TextSize = 12, TextColor3 = T.text, PlaceholderText = "#RRGGBB",
        PlaceholderColor3 = T.muted, ClearTextOnFocus = false, Text = "",
    }, panelF)
    corner(hexBox, 6)
    hoverFx(hexBox, hexBox, inner)
    hexBox.FocusLost:Connect(function()
        local c = Util.parseHex(hexBox.Text)
        if c then setCfg(key, c) else hexBox.Text = Util.hex(Cfg[key]) end
    end)

    local row = new("Frame", { Size = UDim2.new(1, 0, 0, 26), BackgroundTransparency = 1, LayoutOrder = 5 }, panelF)
    new("UIListLayout", { FillDirection = Enum.FillDirection.Horizontal, Padding = UDim.new(0, 4) }, row)
    for _, pc in ipairs(PRESETS) do
        local pb = new("TextButton", { Size = UDim2.fromOffset(22, 22), BackgroundColor3 = pc, BorderSizePixel = 0, Text = "" }, row)
        corner(pb, 6)
        local ps = new("UIStroke", { Color = T.text, Thickness = 1.5, Transparency = 1, ApplyStrokeMode = Enum.ApplyStrokeMode.Border }, pb)
        pb.MouseEnter:Connect(function() tween(ps, { Transparency = 0.2 }) end)
        pb.MouseLeave:Connect(function() tween(ps, { Transparency = 1 }) end)
        pb.Activated:Connect(function() setCfg(key, pc) end)
    end

    local function paint()
        local c = Cfg[key]
        swatch.BackgroundColor3 = c
        hexLbl.Text = "#" .. Util.hex(c)
        hexBox.Text = Util.hex(c)
        rS.set(c.R * 255, true)
        gS.set(c.G * 255, true)
        bS.set(c.B * 255, true)
    end
    reg(key, paint)
    paint()
    head.Activated:Connect(function()
        panelF.Visible = not panelF.Visible
        if panelF.Visible then Kit.pop(panelF, 0.94) end
    end)
end

--------------------------------------------------------
-- Group: bagian yang bisa dilipat (titik warna + nama + status ON/OFF).
-- Mengembalikan "page" anak; panggil g:Toggle(...), g:Slider(...), dst.
--------------------------------------------------------
function Page:Group(title, colKey, onKey)
    local wrap = new("Frame", {
        Size = UDim2.new(1, 0, 0, 0), AutomaticSize = Enum.AutomaticSize.Y,
        BackgroundColor3 = T.surface, BorderSizePixel = 0, LayoutOrder = self:next(),
    }, self.sf)
    corner(wrap, 8)
    new("UIStroke", { Color = T.outline, Thickness = 2 }, wrap)
    new("UIListLayout", { SortOrder = Enum.SortOrder.LayoutOrder, Padding = UDim.new(0, 4) }, wrap)

    local head = new("TextButton", {
        Size = UDim2.new(1, 0, 0, 38), BackgroundColor3 = T.surface, BorderSizePixel = 0,
        AutoButtonColor = false, Text = "", LayoutOrder = 1,
    }, wrap)
    corner(head, 8)
    hoverFx(head, head, T.surface)
    local dot = new("Frame", { Position = UDim2.fromOffset(12, 14), Size = UDim2.fromOffset(10, 10), BackgroundColor3 = Cfg[colKey], BorderSizePixel = 0 }, head)
    corner(dot, 5)
    reg(colKey, function() dot.BackgroundColor3 = Cfg[colKey] end)
    local t = lbl(head, title, 12, T.text, Enum.Font.GothamBold)
    t.Position, t.Size = UDim2.fromOffset(32, 0), UDim2.new(1, -110, 1, 0)
    local st = lbl(head, "", 10, T.muted, Enum.Font.GothamBold, Enum.TextXAlignment.Right)
    st.AnchorPoint, st.Position, st.Size = Vector2.new(1, 0), UDim2.new(1, -30, 0, 0), UDim2.fromOffset(50, 38)
    local chev = lbl(head, "▸", 12, T.muted, Enum.Font.GothamBold, Enum.TextXAlignment.Center)
    chev.TextYAlignment = Enum.TextYAlignment.Center
    chev.Position, chev.Size = UDim2.new(1, -26, 0, 0), UDim2.fromOffset(20, 38)
    local function paintStatus()
        st.Text = Cfg[onKey] and "ON" or "OFF"
        st.TextColor3 = Cfg[onKey] and Cfg.Accent or T.muted
    end
    reg(onKey, paintStatus)
    onAccent(paintStatus)

    local bodyF = new("Frame", {
        Size = UDim2.new(1, 0, 0, 0), AutomaticSize = Enum.AutomaticSize.Y,
        BackgroundTransparency = 1, Visible = false, LayoutOrder = 2,
    }, wrap)
    new("UIListLayout", { SortOrder = Enum.SortOrder.LayoutOrder, Padding = UDim.new(0, 4) }, bodyF)
    new("UIPadding", { PaddingLeft = UDim.new(0, 6), PaddingRight = UDim.new(0, 6), PaddingBottom = UDim.new(0, 8) }, bodyF)
    head.Activated:Connect(function()
        bodyF.Visible = not bodyF.Visible
        spring(chev, { Rotation = bodyF.Visible and 90 or 0 }, 0.3)
        if bodyF.Visible then Kit.pop(bodyF, 0.94) end
    end)
    return setmetatable({ sf = bodyF, n = 0, bg = T.raised }, Page)
end

return Page
end,
["ui/FloatButton"] = function(...)
-- Tombol melayang berbentuk blok "?" Mario: tanda tanya melayang naik-turun, membal saat disentuh.
-- Tap = buka/tutup window, geser = pindah.
local Hub = ...
local Config = Hub.use("config/Config")
local Cfg = Config.Cfg
local Kit = Hub.use("ui/Kit")
local Root = Hub.use("ui/Root")
local Window = Hub.use("ui/Window")
local new, corner, lbl = Kit.new, Kit.corner, Kit.lbl
local Drag = Kit.Drag

local GOLD = Color3.fromRGB(252, 190, 40)
local BROWN = Color3.fromRGB(122, 66, 14)

local float = new("TextButton", {
    Size = UDim2.fromOffset(40, 40), Position = UDim2.new(0, 12, 0.5, -20),
    BackgroundColor3 = GOLD, BorderSizePixel = 0, AutoButtonColor = false, Text = "",
}, Root.gui)
corner(float, 6)
new("UIStroke", { Color = BROWN, Thickness = 3, ApplyStrokeMode = Enum.ApplyStrokeMode.Border }, float)

-- paku di empat sudut
for _, p in ipairs({ { 4, 4 }, { 32, 4 }, { 4, 32 }, { 32, 32 } }) do
    corner(new("Frame", { Position = UDim2.fromOffset(p[1], p[2]), Size = UDim2.fromOffset(4, 4), BackgroundColor3 = BROWN, BorderSizePixel = 0 }, float), 2)
end

local q = lbl(float, "?", 24, BROWN, Kit.FONT, Enum.TextXAlignment.Center)
q.Size = UDim2.fromScale(1, 1)
q.TextYAlignment = Enum.TextYAlignment.Center
Kit.loop(q, { Position = UDim2.fromOffset(0, -3) }, 0.55)

local sc = Kit.scaleOf(float)
float.MouseEnter:Connect(function() Kit.spring(sc, { Scale = 1.14 }, 0.25) end)
float.MouseLeave:Connect(function() Kit.spring(sc, { Scale = 1 }, 0.25) end)
float.Visible = Cfg.ShowFloat
Config.reg("ShowFloat", function()
    float.Visible = Cfg.ShowFloat
    if Cfg.ShowFloat then Kit.pop(float, 0.5) end
end)

float.InputBegan:Connect(function(i)
    if not Kit.isPress(i) then return end
    local sp, st, moved = i.Position, float.Position, 0
    Drag.fn = function(pos)
        local d = pos - sp
        moved = math.max(moved, d.Magnitude)
        float.Position = UDim2.new(st.X.Scale, st.X.Offset + d.X, st.Y.Scale, st.Y.Offset + d.Y)
    end
    Drag.done = function()
        if moved < 6 then
            Kit.pop(float, 0.7)
            Window.toggle()
        end
    end
end)

return float
end,
["ui/FovCircle"] = function(...)
-- Lingkaran FOV aim (digambar di overlay, diperbarui tiap RenderStep).
local Hub = ...
local RunService = game:GetService("RunService")
local Cfg = Hub.use("config/Config").Cfg
local Kit = Hub.use("ui/Kit")
local Root = Hub.use("ui/Root")

local circle = Kit.new("Frame", {
    AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(0.5, 0, 0.5, 0),
    BackgroundTransparency = 1, Visible = false,
}, Root.overlay)
Kit.corner(circle, 9999)
local stroke = Kit.new("UIStroke", { Thickness = 1, Color = Cfg.FOVColor, ApplyStrokeMode = Enum.ApplyStrokeMode.Border }, circle)

local function update()
    local show = Cfg.ShowFOV and (Cfg.Aimlock or Cfg.Silent)
    circle.Visible = show
    if show then
        circle.Size = UDim2.fromOffset(Cfg.FOV * 2, Cfg.FOV * 2)
        stroke.Color = Cfg.FOVColor
    end
end

RunService:BindToRenderStep("TOFHubFOV", Enum.RenderPriority.Last.Value, update)
Hub.onUnload(function()
    pcall(function() RunService:UnbindFromRenderStep("TOFHubFOV") end)
end)

return { circle = circle }
end,
["ui/Kit"] = function(...)
-- Tema + helper UI kecil (pembuat instance, tween, hover, aksen, drag global, animasi ala Mario).
-- Semua animasi mengikuti Cfg.UIAnim: bila dimatikan, nilai langsung diterapkan tanpa tween.
local Hub = ...
local TweenService = game:GetService("TweenService")
local UIS = game:GetService("UserInputService")
local Config = Hub.use("config/Config")
local Cfg = Config.Cfg
local Theme = Hub.use("ui/Theme")

local Kit = {}
Kit.T = Theme.T
local T = Kit.T

-- font judul ala game (Fredoka); cadangan GothamBold bila tidak ada
local okF, fredoka = pcall(function() return Enum.Font.FredokaOne end)
Kit.FONT = okF and fredoka or Enum.Font.GothamBold

function Kit.new(class, props, parent)
    local o = Instance.new(class)
    for k, v in pairs(props or {}) do o[k] = v end
    if parent then o.Parent = parent end
    return o
end
local new = Kit.new

function Kit.corner(o, r) return new("UICorner", { CornerRadius = UDim.new(0, r) }, o) end

function Kit.lbl(parent, txt, size, color, font, align)
    return new("TextLabel", {
        BackgroundTransparency = 1, Text = txt, TextSize = size, TextColor3 = color,
        Font = font or Enum.Font.GothamMedium,
        TextXAlignment = align or Enum.TextXAlignment.Left,
    }, parent)
end

function Kit.isPress(i)
    return i.UserInputType == Enum.UserInputType.MouseButton1 or i.UserInputType == Enum.UserInputType.Touch
end

--------------------------------------------------------
-- Animasi
--------------------------------------------------------
function Kit.animOn() return Cfg.UIAnim ~= false end

local function setNow(o, props)
    for k, v in pairs(props) do pcall(function() o[k] = v end) end
end

-- tween biasa (Quad Out). UIAnim mati -> langsung set nilai akhir, mengembalikan nil
function Kit.tween(o, props, t, style, dir)
    if not Kit.animOn() then setNow(o, props) return nil end
    local tw = TweenService:Create(o, TweenInfo.new(t or 0.15, style or Enum.EasingStyle.Quad, dir or Enum.EasingDirection.Out), props)
    tw:Play()
    return tw
end
local tween = Kit.tween

-- "membal": melewati target sedikit lalu kembali (Back Out) — kesan blok Mario
function Kit.spring(o, props, t)
    return tween(o, props, t or 0.32, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
end

-- memantul seperti bola (Bounce Out)
function Kit.bounce(o, props, t)
    return tween(o, props, t or 0.45, Enum.EasingStyle.Bounce, Enum.EasingDirection.Out)
end

function Kit.scaleOf(o)
    local s = o:FindFirstChildOfClass("UIScale")
    if not s then s = new("UIScale", { Scale = 1 }, o) end
    return s
end

-- kembung sebentar lalu membal ke ukuran normal (efek blok "dipukul" dari bawah)
function Kit.pop(o, from)
    local s = Kit.scaleOf(o)
    if not Kit.animOn() then s.Scale = 1 return end
    s.Scale = from or 0.88
    Kit.spring(s, { Scale = 1 }, 0.38)
end

-- tombol terasa ditekan: mengecil saat ditahan, membal saat dilepas
function Kit.pressFx(btn, target)
    local s = Kit.scaleOf(target or btn)
    btn.MouseButton1Down:Connect(function() tween(s, { Scale = 0.94 }, 0.07) end)
    btn.MouseButton1Up:Connect(function() Kit.spring(s, { Scale = 1 }, 0.32) end)
    btn.MouseLeave:Connect(function() tween(s, { Scale = 1 }, 0.12) end)
end

-- jalankan fn(nilai) dari `from` ke `to` dengan easing bebas (untuk animasi gabungan skala+posisi)
function Kit.drive(from, to, t, style, dir, fn)
    if not Kit.animOn() then fn(to) return nil end
    local nv = Instance.new("NumberValue")
    nv.Value = from
    local conn = nv.Changed:Connect(fn)
    local tw = TweenService:Create(nv, TweenInfo.new(t, style or Enum.EasingStyle.Quad, dir or Enum.EasingDirection.Out), { Value = to })
    tw.Completed:Connect(function()
        conn:Disconnect()
        nv:Destroy()
        fn(to)
    end)
    fn(from)
    tw:Play()
    return tw
end

-- animasi berulang bolak-balik (koin berputar, tanda "?" melayang). Berhenti bila UIAnim dimatikan.
local loops = {}
function Kit.loop(o, props, t, style)
    local tw = TweenService:Create(o, TweenInfo.new(t, style or Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), props)
    loops[#loops + 1] = tw
    if Kit.animOn() then tw:Play() end
    return tw
end
Config.reg("UIAnim", function()
    for _, tw in ipairs(loops) do
        pcall(function() if Kit.animOn() then tw:Play() else tw:Pause() end end)
    end
end)

-- hover manis: latar berubah ke steel blue + garis tepi lembut muncul
function Kit.hoverFx(target, trigger, base)
    base = base or T.surface
    local st = new("UIStroke", {
        Color = T.steelEdge, Thickness = 1, Transparency = 1,
        ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
    }, target)
    trigger.MouseEnter:Connect(function()
        tween(target, { BackgroundColor3 = T.steel }, 0.16)
        tween(st, { Transparency = 0.45 }, 0.16)
    end)
    trigger.MouseLeave:Connect(function()
        tween(target, { BackgroundColor3 = base }, 0.22)
        tween(st, { Transparency = 1 }, 0.22)
    end)
end

-- warna aksen: daftarkan fungsi yang mengecat ulang saat Cfg.Accent berubah
local AccentFns = {}
function Kit.onAccent(fn)
    AccentFns[#AccentFns + 1] = fn
    pcall(fn)
end
Config.reg("Accent", function()
    for _, fn in ipairs(AccentFns) do pcall(fn) end
end)

-- drag global (window, resize, slider, tombol melayang): set Drag.fn / Drag.done saat tekan
local Drag = { fn = nil, done = nil }
Kit.Drag = Drag
Hub.track(UIS.InputChanged:Connect(function(i)
    if Drag.fn and (i.UserInputType == Enum.UserInputType.MouseMovement
        or i.UserInputType == Enum.UserInputType.Touch) then
        Drag.fn(i.Position)
    end
end))
Hub.track(UIS.InputEnded:Connect(function(i)
    if Drag.fn and Kit.isPress(i) then
        Drag.fn = nil
        if Drag.done then local d = Drag.done Drag.done = nil d() end
    end
end))

return Kit
end,
["ui/Page"] = function(...)
-- Sistem halaman/tab + komponen tata letak (Header, Section, Info, Tiles, Button).
-- Kontrol interaktif (Toggle, Slider, Choice, Input, Color, Group) ada di ui/Controls.
--   local page = Page.new("Nama")   -> tombol tab di sidebar + ScrollingFrame
--   Page.select(page)               -> tampilkan halaman
local Hub = ...
local Cfg = Hub.use("config/Config").Cfg
local Kit = Hub.use("ui/Kit")
local Window = Hub.use("ui/Window")
local T, new, corner, lbl, tween, hoverFx, onAccent = Kit.T, Kit.new, Kit.corner, Kit.lbl, Kit.tween, Kit.hoverFx, Kit.onAccent
local spring = Kit.spring

local Page = {}
Page.__index = Page
Page.list = {}
local tabButtons = {}

function Page.select(p)
    for _, q in ipairs(Page.list) do
        if q == p then
            if not q.sf.Visible then
                -- halaman baru naik membal dari bawah
                q.sf.Position = UDim2.fromOffset(0, 16)
                q.sf.Visible = true
                spring(q.sf, { Position = UDim2.fromOffset(0, 0) }, 0.38)
            end
        else
            q.sf.Visible = false
        end
    end
    for q, tb in pairs(tabButtons) do
        local on = (q == p)
        local changed = (tb.on ~= on)
        tb.on = on
        tween(tb.btn, { BackgroundTransparency = on and 0.05 or 1, BackgroundColor3 = T.steel })
        tb.lbl.TextColor3 = on and T.text or T.muted
        if on and changed then
            tb.ind.Visible = true
            tb.ind.Size = UDim2.fromOffset(3, 0)
            spring(tb.ind, { Size = UDim2.fromOffset(3, 16) }, 0.4)
            Kit.pop(tb.btn, 0.9)
        elseif not on then
            tb.ind.Visible = false
        end
    end
end

function Page.new(name)
    local sf = new("ScrollingFrame", {
        Size = UDim2.new(1, 0, 1, 0), BackgroundTransparency = 1, BorderSizePixel = 0,
        ScrollBarThickness = 2, ScrollBarImageColor3 = T.steelEdge,
        CanvasSize = UDim2.new(), AutomaticCanvasSize = Enum.AutomaticSize.Y, Visible = false,
    }, Window.content)
    new("UIListLayout", { Padding = UDim.new(0, 6), SortOrder = Enum.SortOrder.LayoutOrder }, sf)
    new("UIPadding", { PaddingRight = UDim.new(0, 5), PaddingBottom = UDim.new(0, 6) }, sf)
    local p = setmetatable({ sf = sf, n = 0 }, Page)
    Page.list[#Page.list + 1] = p

    local b = new("TextButton", {
        Size = UDim2.new(1, 0, 0, 30), BackgroundColor3 = T.steel, BackgroundTransparency = 1,
        AutoButtonColor = false, Text = "", LayoutOrder = #Page.list,
    }, Window.sidebar)
    corner(b, 2)
    local ind = new("Frame", { AnchorPoint = Vector2.new(0, 0.5), Size = UDim2.fromOffset(3, 16), Position = UDim2.new(0, 0, 0.5, 0), BackgroundColor3 = Cfg.Accent, BorderSizePixel = 0, Visible = false }, b)
    corner(ind, 2)
    onAccent(function() ind.BackgroundColor3 = Cfg.Accent end)
    local l = lbl(b, name, 13, T.muted, Kit.FONT)
    l.Position, l.Size = UDim2.fromOffset(12, 0), UDim2.new(1, -14, 1, 0)
    l.TextScaled = true -- nama panjang (mis. "Violence District") tetap muat
    new("UITextSizeConstraint", { MaxTextSize = 13, MinTextSize = 8 }, l)
    local tb = { btn = b, ind = ind, lbl = l, on = false }
    tabButtons[p] = tb
    b.MouseEnter:Connect(function()
        if not tb.on then
            tween(b, { BackgroundTransparency = 0.45 })
            tween(l, { TextColor3 = T.text })
        end
    end)
    b.MouseLeave:Connect(function()
        if not tb.on then
            tween(b, { BackgroundTransparency = 1 })
            tween(l, { TextColor3 = T.muted })
        end
    end)
    Kit.pressFx(b)
    b.Activated:Connect(function() Page.select(p) end)
    return p
end

function Page:next() self.n += 1 return self.n end
function Page:base() return self.bg or T.surface end
function Page:inner() return (self.bg == T.raised) and T.surface or T.raised end

function Page:card(h)
    local f = new("Frame", {
        Size = UDim2.new(1, 0, 0, h), BackgroundColor3 = self:base(), BorderSizePixel = 0, LayoutOrder = self:next(),
    }, self.sf)
    corner(f, 4)
    new("UIStroke", { Color = T.outline, Thickness = 2 }, f)
    return f
end

function Page:Header(txt, sub)
    local f = new("Frame", { Size = UDim2.new(1, 0, 0, sub and 40 or 26), BackgroundTransparency = 1, LayoutOrder = self:next() }, self.sf)
    local t = lbl(f, txt, 19, T.text, Kit.FONT)
    t.Size = UDim2.new(1, 0, 0, 22)
    if sub then
        local s = lbl(f, sub, 11, T.muted)
        s.Position, s.Size = UDim2.fromOffset(0, 22), UDim2.new(1, 0, 0, 14)
    end
end

function Page:Section(txt)
    local f = new("Frame", { Size = UDim2.new(1, 0, 0, 22), BackgroundTransparency = 1, LayoutOrder = self:next() }, self.sf)
    local bar = new("Frame", { Size = UDim2.fromOffset(3, 10), Position = UDim2.fromOffset(0, 8), BackgroundColor3 = Cfg.Accent, BorderSizePixel = 0 }, f)
    corner(bar, 2)
    onAccent(function() bar.BackgroundColor3 = Cfg.Accent end)
    local l = lbl(f, string.upper(txt), 10, T.muted, Enum.Font.GothamBold)
    l.Position, l.Size = UDim2.fromOffset(10, 3), UDim2.new(1, -10, 0, 16)
end

function Page:Info(txt, rich)
    local f = new("Frame", {
        Size = UDim2.new(1, 0, 0, 0), AutomaticSize = Enum.AutomaticSize.Y,
        BackgroundColor3 = self:base(), BorderSizePixel = 0, LayoutOrder = self:next(),
    }, self.sf)
    corner(f, 3)
    new("UIStroke", { Color = T.outline, Thickness = 1 }, f)
    new("UIPadding", { PaddingTop = UDim.new(0, 9), PaddingBottom = UDim.new(0, 9), PaddingLeft = UDim.new(0, 12), PaddingRight = UDim.new(0, 12) }, f)
    local l = lbl(f, txt, 11, T.text)
    l.Size, l.AutomaticSize = UDim2.new(1, 0, 0, 0), Enum.AutomaticSize.Y
    l.TextWrapped, l.TextYAlignment, l.RichText = true, Enum.TextYAlignment.Top, rich == true
    return l
end

-- defs = { {id, "LABEL"}, ... } -> tabel id -> TextLabel nilai
function Page:Tiles(defs)
    local rows = math.ceil(#defs / 2)
    local g = new("Frame", { Size = UDim2.new(1, 0, 0, rows * 52 + (rows - 1) * 6), BackgroundTransparency = 1, LayoutOrder = self:next() }, self.sf)
    new("UIGridLayout", { CellSize = UDim2.new(0.5, -3, 0, 52), CellPadding = UDim2.fromOffset(6, 6), SortOrder = Enum.SortOrder.LayoutOrder }, g)
    local vals = {}
    for i, d in ipairs(defs) do
        local c = new("Frame", { BackgroundColor3 = T.surface, BorderSizePixel = 0, LayoutOrder = i }, g)
        corner(c, 8)
        hoverFx(c, c, T.surface)
        local l = lbl(c, d[2], 9, T.muted, Enum.Font.GothamBold)
        l.Position, l.Size = UDim2.fromOffset(12, 8), UDim2.new(1, -24, 0, 12)
        local v = lbl(c, "-", 16, T.text, Enum.Font.GothamBold)
        v.Position, v.Size = UDim2.fromOffset(12, 23), UDim2.new(1, -24, 0, 22)
        v.TextTruncate = Enum.TextTruncate.AtEnd
        vals[d[1]] = v
    end
    return vals
end

-- kind: nil | "accent" | "danger"
function Page:Button(txt, cb, kind)
    local b = new("TextButton", {
        Size = UDim2.new(1, 0, 0, 32), BackgroundColor3 = self:base(), BorderSizePixel = 0, AutoButtonColor = false,
        Text = txt, TextSize = 12, Font = Enum.Font.GothamMedium, TextColor3 = T.text, LayoutOrder = self:next(),
    }, self.sf)
    corner(b, 8)
    if kind == "accent" then
        b.TextColor3, b.Font = T.bg, Enum.Font.GothamBold
        onAccent(function() b.BackgroundColor3 = Cfg.Accent end)
        b.MouseEnter:Connect(function() tween(b, { BackgroundColor3 = Cfg.Accent:Lerp(Color3.new(1, 1, 1), 0.2) }) end)
        b.MouseLeave:Connect(function() tween(b, { BackgroundColor3 = Cfg.Accent }) end)
    else
        if kind == "danger" then b.TextColor3 = T.danger end
        hoverFx(b, b, self:base())
    end
    Kit.pressFx(b)
    b.Activated:Connect(cb)
    return b
end

return Page
end,
["ui/Root"] = function(...)
-- Wadah GUI tingkat atas: ScreenGui utama, overlay (FOV), dan folder ESP.
-- PENTING: ESP (Highlight/BillboardGui) diparenti langsung ke container, BUKAN ke ScreenGui
-- (BillboardGui di dalam ScreenGui tidak tampil).
local Hub = ...
local new = Hub.use("ui/Kit").new

local container = (gethui and gethui()) or game:GetService("CoreGui")

local Root = {
    container = container,
    gui = new("ScreenGui", { Name = "TOFHub", ResetOnSpawn = false, ZIndexBehavior = Enum.ZIndexBehavior.Sibling }, container),
    overlay = new("ScreenGui", { Name = "TOFHubOverlay", ResetOnSpawn = false, IgnoreGuiInset = true, DisplayOrder = 5 }, container),
    espFolder = new("Folder", { Name = "TOFESP" }, container),
}

Hub.onUnload(function()
    pcall(function() Root.espFolder:Destroy() end)
    Root.gui:Destroy()
    Root.overlay:Destroy()
end)

return Root
end,
["ui/Theme"] = function(...)
-- Enam palet UI bergaya blok Mario. Hanya tampilan; tidak mengubah fitur game.
local Hub = ...
local Config = Hub.use("config/Config")
local Cfg = Config.Cfg

local Theme = {}
Theme.T = {
    bg=Color3.fromRGB(12,13,18), surface=Color3.fromRGB(20,22,29),
    raised=Color3.fromRGB(28,31,41), steel=Color3.fromRGB(35,50,74),
    steelEdge=Color3.fromRGB(92,130,186), track=Color3.fromRGB(48,54,72),
    stroke=Color3.fromRGB(42,47,62), text=Color3.fromRGB(236,239,247),
    muted=Color3.fromRGB(136,143,162), danger=Color3.fromRGB(240,80,90),
    top=Color3.fromRGB(35,116,196), topText=Color3.fromRGB(255,255,255),
    side=Color3.fromRGB(91,54,35), outline=Color3.fromRGB(31,24,21),
}
local T=Theme.T
local palettes = {
    Overworld={bg=Color3.fromRGB(244,225,180),surface=Color3.fromRGB(255,244,211),raised=Color3.fromRGB(235,211,160),steel=Color3.fromRGB(209,185,135),steelEdge=Color3.fromRGB(116,76,45),track=Color3.fromRGB(191,168,128),stroke=Color3.fromRGB(91,58,38),text=Color3.fromRGB(48,38,31),muted=Color3.fromRGB(116,91,68),danger=Color3.fromRGB(190,48,48),top=Color3.fromRGB(47,139,220),topText=Color3.fromRGB(255,255,255),side=Color3.fromRGB(117,70,43),outline=Color3.fromRGB(55,35,24)},
    Light={bg=Color3.fromRGB(239,231,211),surface=Color3.fromRGB(255,249,231),raised=Color3.fromRGB(229,216,188),steel=Color3.fromRGB(213,194,159),steelEdge=Color3.fromRGB(142,102,67),track=Color3.fromRGB(194,178,150),stroke=Color3.fromRGB(112,79,54),text=Color3.fromRGB(54,43,34),muted=Color3.fromRGB(127,108,88),danger=Color3.fromRGB(190,55,55),top=Color3.fromRGB(185,69,53),topText=Color3.fromRGB(255,255,255),side=Color3.fromRGB(126,88,59),outline=Color3.fromRGB(58,39,27)},
    Dark={bg=Color3.fromRGB(24,25,29),surface=Color3.fromRGB(35,37,43),raised=Color3.fromRGB(46,49,57),steel=Color3.fromRGB(58,62,72),steelEdge=Color3.fromRGB(125,132,148),track=Color3.fromRGB(68,72,83),stroke=Color3.fromRGB(15,16,19),text=Color3.fromRGB(242,243,246),muted=Color3.fromRGB(159,164,175),danger=Color3.fromRGB(244,79,85),top=Color3.fromRGB(48,51,59),topText=Color3.fromRGB(255,255,255),side=Color3.fromRGB(31,33,39),outline=Color3.fromRGB(8,9,11)},
    Underground={bg=Color3.fromRGB(14,25,43),surface=Color3.fromRGB(22,39,63),raised=Color3.fromRGB(30,51,79),steel=Color3.fromRGB(39,67,101),steelEdge=Color3.fromRGB(70,142,205),track=Color3.fromRGB(44,62,85),stroke=Color3.fromRGB(8,15,28),text=Color3.fromRGB(226,239,255),muted=Color3.fromRGB(139,166,195),danger=Color3.fromRGB(255,88,83),top=Color3.fromRGB(21,66,112),topText=Color3.fromRGB(255,255,255),side=Color3.fromRGB(12,24,42),outline=Color3.fromRGB(5,12,24)},
    Castle={bg=Color3.fromRGB(42,27,25),surface=Color3.fromRGB(59,38,34),raised=Color3.fromRGB(76,48,41),steel=Color3.fromRGB(94,56,45),steelEdge=Color3.fromRGB(177,105,62),track=Color3.fromRGB(87,61,53),stroke=Color3.fromRGB(22,13,12),text=Color3.fromRGB(255,231,211),muted=Color3.fromRGB(190,151,129),danger=Color3.fromRGB(239,76,62),top=Color3.fromRGB(133,47,37),topText=Color3.fromRGB(255,239,217),side=Color3.fromRGB(58,30,27),outline=Color3.fromRGB(18,10,9)},
    ["Star Road"]={bg=Color3.fromRGB(35,24,63),surface=Color3.fromRGB(49,34,83),raised=Color3.fromRGB(64,45,105),steel=Color3.fromRGB(82,56,128),steelEdge=Color3.fromRGB(177,132,255),track=Color3.fromRGB(75,60,105),stroke=Color3.fromRGB(18,12,36),text=Color3.fromRGB(247,235,255),muted=Color3.fromRGB(183,160,213),danger=Color3.fromRGB(255,91,139),top=Color3.fromRGB(91,53,150),topText=Color3.fromRGB(255,245,255),side=Color3.fromRGB(40,27,73),outline=Color3.fromRGB(15,9,30)},
}
Theme.names={"Overworld","Light","Dark","Underground","Castle","Star Road"}
local function recolor(root, old, new)
    if not root then return end
    local props={"BackgroundColor3","TextColor3","ImageColor3","BorderColor3","Color"}
    for _,obj in ipairs(root:GetDescendants()) do
        for _,prop in ipairs(props) do
            local ok,value=pcall(function() return obj[prop] end)
            if ok and typeof(value)=="Color3" then
                for key,oldColor in pairs(old) do
                    if value==oldColor then pcall(function() obj[prop]=new[key] end) break end
                end
            end
        end
    end
end
function Theme.apply(name, root)
    local p=palettes[name] or palettes.Overworld
    local old={}
    for k,v in pairs(T) do old[k]=v end
    for k,v in pairs(p) do T[k]=v end
    recolor(root,old,T)
    return name
end
function Theme.set(name, root)
    if not palettes[name] then return false end
    Theme.apply(name,root)
    Config.set("Theme",name)
    return true
end
Theme.apply(Cfg.Theme or "Overworld")
return Theme
end,
["ui/Window"] = function(...)
-- Window utama: panel, title bar (koin berputar, minimize/tutup), sidebar tab, area konten, resize, toast, keybind.
-- Animasi ala Mario: window "muncul membal", koin berputar, garis bintang (star power) berjalan, toast membal.
--   Window.sidebar / Window.content   wadah yang diisi ui/Page
--   Window.toast(msg)  Window.toggle()  Window.setVisible(on)  Window.resetSize()  Window.statLbl
local Hub = ...
local UIS = game:GetService("UserInputService")
local Config = Hub.use("config/Config")
local Cfg = Config.Cfg
local Kit = Hub.use("ui/Kit")
local Root = Hub.use("ui/Root")
local T, new, corner, lbl = Kit.T, Kit.new, Kit.corner, Kit.lbl
local tween, isPress, onAccent, Drag = Kit.tween, Kit.isPress, Kit.onAccent, Kit.Drag

local Theme = Hub.use("ui/Theme")

local TITLE_H = 36
local MINW, MINH = 320, 220
local COIN = Color3.fromRGB(252, 196, 44)
local COIN_EDGE = Color3.fromRGB(150, 98, 12)

local function clampSize(w, h)
    local v = workspace.CurrentCamera.ViewportSize
    return math.clamp(w, MINW, math.max(MINW, v.X - 20)), math.clamp(h, MINH, math.max(MINH, v.Y - 20))
end
local fullW, fullH = clampSize(Cfg.W, Cfg.H)
local minimized = false

local win = new("Frame", {
    Size = UDim2.fromOffset(fullW, fullH), Position = UDim2.new(0.5, -fullW / 2, 0.5, -fullH / 2),
    BackgroundTransparency = 1, Active = true,
}, Root.gui)
local winScale = new("UIScale", { Scale = 1 }, win)
new("ImageLabel", {
    Image = "rbxassetid://6015897843", ImageColor3 = Color3.new(0, 0, 0), ImageTransparency = 0.55,
    ScaleType = Enum.ScaleType.Slice, SliceCenter = Rect.new(49, 49, 450, 450),
    AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(0.5, 0, 0.5, 4),
    Size = UDim2.new(1, 44, 1, 44), BackgroundTransparency = 1, ZIndex = 0,
}, win)
local panel = new("Frame", {
    Size = UDim2.new(1, 0, 1, 0), BackgroundColor3 = T.bg, BorderSizePixel = 0,
    ClipsDescendants = true, ZIndex = 1,
}, win)
corner(panel, 3)
new("UIStroke", { Color = T.outline, Thickness = 3, ApplyStrokeMode = Enum.ApplyStrokeMode.Border }, panel)

--------------------------------------------------------
-- Title bar
--------------------------------------------------------
local titleBar = new("Frame", { Size = UDim2.new(1, 0, 0, TITLE_H), BackgroundColor3 = T.top, BorderSizePixel = 0 }, panel)

-- koin berputar: lebar mengecil-membesar bolak-balik
local coin = new("Frame", {
    AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromOffset(22, TITLE_H / 2),
    Size = UDim2.fromOffset(20, 20), BackgroundColor3 = COIN, BorderSizePixel = 0, ClipsDescendants = true,
}, titleBar)
corner(coin, 10)
new("UIStroke", { Color = COIN_EDGE, Thickness = 2, ApplyStrokeMode = Enum.ApplyStrokeMode.Border }, coin)
local coinT = lbl(coin, "P", 12, COIN_EDGE, Kit.FONT, Enum.TextXAlignment.Center)
coinT.AnchorPoint, coinT.Position, coinT.Size = Vector2.new(0.5, 0.5), UDim2.fromScale(0.5, 0.5), UDim2.fromOffset(20, 20)
Kit.loop(coin, { Size = UDim2.fromOffset(6, 20) }, 0.55)

local title = lbl(titleBar, "PIDI MARIO", 15, T.topText, Kit.FONT)
title.Position, title.Size = UDim2.fromOffset(40, 0), UDim2.fromOffset(110, TITLE_H)

local statLbl = lbl(titleBar, "", 10, T.topText, Enum.Font.Code, Enum.TextXAlignment.Right)
statLbl.AnchorPoint, statLbl.Position, statLbl.Size = Vector2.new(1, 0), UDim2.new(1, -64, 0, 0), UDim2.fromOffset(110, TITLE_H)
statLbl.TextTransparency = 0.25

local function titleBtn(txt, xoff, hoverCol)
    local b = new("TextButton", {
        Size = UDim2.fromOffset(24, 24), Position = UDim2.new(1, xoff, 0, 6),
        BackgroundColor3 = T.steel, BackgroundTransparency = 1, AutoButtonColor = false,
        Text = txt, TextSize = 15, Font = Enum.Font.GothamBold, TextColor3 = T.topText,
    }, titleBar)
    corner(b, 6)
    Kit.pressFx(b)
    b.MouseEnter:Connect(function()
        tween(b, { BackgroundTransparency = 0, BackgroundColor3 = hoverCol or T.steel })
    end)
    b.MouseLeave:Connect(function()
        tween(b, { BackgroundTransparency = 1 })
    end)
    return b
end
local minBtn = titleBtn("–", -58)
local closeBtn = titleBtn("×", -32, T.danger)

-- garis "star power": pelangi yang bergeser terus di bawah title bar
local accentLine = new("Frame", { Position = UDim2.fromOffset(0, TITLE_H), Size = UDim2.new(1, 0, 0, 3), BackgroundColor3 = Color3.new(1, 1, 1), BorderSizePixel = 0 }, panel)
local rainbow = ColorSequence.new({
    ColorSequenceKeypoint.new(0, Color3.fromRGB(235, 60, 60)),
    ColorSequenceKeypoint.new(0.2, Color3.fromRGB(255, 190, 40)),
    ColorSequenceKeypoint.new(0.4, Color3.fromRGB(90, 220, 110)),
    ColorSequenceKeypoint.new(0.6, Color3.fromRGB(60, 190, 240)),
    ColorSequenceKeypoint.new(0.8, Color3.fromRGB(170, 100, 255)),
    ColorSequenceKeypoint.new(1, Color3.fromRGB(235, 60, 60)),
})
local accentGrad = new("UIGradient", { Color = rainbow, Offset = Vector2.new(-0.5, 0) }, accentLine)
Kit.loop(accentGrad, { Offset = Vector2.new(0.5, 0) }, 2.2, Enum.EasingStyle.Linear)

--------------------------------------------------------
-- Body: sidebar + konten
--------------------------------------------------------
local body = new("Frame", { Position = UDim2.fromOffset(0, TITLE_H + 3), Size = UDim2.new(1, 0, 1, -(TITLE_H + 3)), BackgroundTransparency = 1 }, panel)

local sidebar = new("ScrollingFrame", {
    Position = UDim2.fromOffset(7, 7), Size = UDim2.new(0, 92, 1, -14),
    BackgroundColor3 = T.side, BorderSizePixel = 0, ScrollBarThickness = 0,
    CanvasSize = UDim2.new(), AutomaticCanvasSize = Enum.AutomaticSize.Y,
}, body)
corner(sidebar, 3)
new("UIStroke", { Color = T.outline, Thickness = 2 }, sidebar)
new("UIListLayout", { Padding = UDim.new(0, 4), SortOrder = Enum.SortOrder.LayoutOrder }, sidebar)
new("UIPadding", { PaddingTop = UDim.new(0, 4), PaddingBottom = UDim.new(0, 4), PaddingLeft = UDim.new(0, 4), PaddingRight = UDim.new(0, 4) }, sidebar)

local content = new("Frame", {
    Position = UDim2.fromOffset(108, 7), Size = UDim2.new(1, -115, 1, -14), BackgroundTransparency = 1,
    ClipsDescendants = true,
}, body)

local grip = new("TextButton", {
    AnchorPoint = Vector2.new(1, 1), Position = UDim2.new(1, -3, 1, -3), Size = UDim2.fromOffset(18, 18),
    BackgroundTransparency = 1, Text = "◢", TextSize = 11, TextColor3 = T.muted, ZIndex = 10,
}, panel)
grip.MouseEnter:Connect(function() tween(grip, { TextColor3 = T.steelEdge }) end)
grip.MouseLeave:Connect(function() tween(grip, { TextColor3 = T.muted }) end)

local function sizeTarget()
    if minimized then return UDim2.fromOffset(math.min(fullW, 240), TITLE_H) end
    return UDim2.fromOffset(fullW, fullH)
end

-- animate = true: ukuran berubah membal (dipakai minimize); resize lewat grip tetap langsung
local function applySize(animate)
    minBtn.Text = minimized and "+" or "–"
    if animate and Kit.animOn() then
        if not minimized then
            body.Visible, accentLine.Visible, grip.Visible = true, true, true
        end
        local tw = Kit.spring(win, { Size = sizeTarget() }, 0.34)
        if minimized and tw then
            tw.Completed:Connect(function()
                if minimized then body.Visible, accentLine.Visible, grip.Visible = false, false, false end
            end)
        end
        return
    end
    win.Size = sizeTarget()
    body.Visible = not minimized
    accentLine.Visible = not minimized
    grip.Visible = not minimized
end
minBtn.Activated:Connect(function() minimized = not minimized applySize(true) end)

titleBar.InputBegan:Connect(function(i)
    if isPress(i) then
        local sp, st = i.Position, win.Position
        Drag.fn = function(pos)
            local d = pos - sp
            win.Position = UDim2.new(st.X.Scale, st.X.Offset + d.X, st.Y.Scale, st.Y.Offset + d.Y)
        end
    end
end)

grip.InputBegan:Connect(function(i)
    if isPress(i) then
        local sp, sw, sh = i.Position, fullW, fullH
        Drag.fn = function(pos)
            fullW, fullH = clampSize(sw + (pos.X - sp.X), sh + (pos.Y - sp.Y))
            Cfg.W, Cfg.H = fullW, fullH
            win.Size = sizeTarget()
            Config.markDirty()
        end
    end
end)

-- ukuran berubah dari luar (muat config / reset): ikuti nilai Cfg.W / Cfg.H
local function followCfgSize()
    fullW, fullH = clampSize(Cfg.W, Cfg.H)
    applySize(false)
end
Config.reg("W", followCfgSize)
Config.reg("H", followCfgSize)

--------------------------------------------------------
-- Toast (membal masuk dari bawah)
--------------------------------------------------------
local toastLbl = new("TextLabel", {
    AnchorPoint = Vector2.new(0.5, 1), Position = UDim2.new(0.5, 0, 1, 40), Size = UDim2.fromOffset(0, 26),
    AutomaticSize = Enum.AutomaticSize.X, BackgroundColor3 = T.steel, BorderSizePixel = 0,
    Font = Enum.Font.GothamBold, TextSize = 11, TextColor3 = T.text, Text = "", Visible = false, ZIndex = 30,
}, panel)
corner(toastLbl, 8)
new("UIPadding", { PaddingLeft = UDim.new(0, 12), PaddingRight = UDim.new(0, 12) }, toastLbl)
new("UIStroke", { Color = T.steelEdge, Transparency = 0.2, Thickness = 2, ApplyStrokeMode = Enum.ApplyStrokeMode.Border }, toastLbl)
local toastTok = 0
local TOAST_UP, TOAST_DOWN = UDim2.new(0.5, 0, 1, -12), UDim2.new(0.5, 0, 1, 40)

--------------------------------------------------------
-- API publik
--------------------------------------------------------
local Window = {
    win = win, panel = panel, sidebar = sidebar, content = content,
    statLbl = statLbl, closeBtn = closeBtn,
}

function Window.toast(msg)
    toastTok += 1
    local t = toastTok
    toastLbl.Text = "★ " .. msg
    if not toastLbl.Visible then toastLbl.Position = TOAST_DOWN end
    toastLbl.Visible = true
    Kit.spring(toastLbl, { Position = TOAST_UP }, 0.38)
    task.delay(2.2, function()
        if t ~= toastTok then return end
        local tw = tween(toastLbl, { Position = TOAST_DOWN }, 0.2)
        if tw then
            tw.Completed:Connect(function() if t == toastTok then toastLbl.Visible = false end end)
        else
            toastLbl.Visible = false
        end
    end)
end

-- tampil/sembunyi dengan animasi skala membal; posisi dijaga supaya window membesar dari tengahnya
local shown = true
local animTok = 0
local basePos = win.Position
local function setScale(s)
    s = math.max(s, 0.01)
    winScale.Scale = s
    local sx, sy = win.Size.X.Offset, win.Size.Y.Offset
    win.Position = UDim2.new(basePos.X.Scale, basePos.X.Offset + sx * (1 - s) / 2, basePos.Y.Scale, basePos.Y.Offset + sy * (1 - s) / 2)
end

function Window.setVisible(on)
    if on == shown then return end
    shown = on
    animTok += 1
    local tok = animTok
    basePos = win.Position
    if not Kit.animOn() then
        winScale.Scale = 1
        win.Visible = on
        return
    end
    if on then
        win.Visible = true
        local tw = Kit.drive(0.55, 1, 0.42, Enum.EasingStyle.Back, Enum.EasingDirection.Out, setScale)
        if tw then
            tw.Completed:Connect(function()
                if tok == animTok then winScale.Scale = 1 win.Position = basePos end
            end)
        end
    else
        local tw = Kit.drive(1, 0.05, 0.22, Enum.EasingStyle.Back, Enum.EasingDirection.In, setScale)
        if tw then
            tw.Completed:Connect(function()
                if tok == animTok then
                    win.Visible = false
                    winScale.Scale = 1
                    win.Position = basePos
                end
            end)
        end
    end
end

function Window.toggle() Window.setVisible(not shown) end

function Window.resetSize()
    fullW, fullH = clampSize(Config.Default.W, Config.Default.H)
    Cfg.W, Cfg.H = fullW, fullH
    minimized = false
    applySize(true)
    Config.markDirty()
end

closeBtn.Activated:Connect(function() Hub.unload() end)

Hub.track(UIS.InputBegan:Connect(function(i, gpe)
    if not gpe and i.KeyCode == Enum.KeyCode.RightShift then Window.toggle() end
end))

-- muncul pertama kali: dimulai tersembunyi lalu "pop" setelah semua tab selesai dibuat
shown = false
win.Visible = false
task.defer(function()
    if not Hub.Dead then Window.setVisible(true) end
end)

return Window
end,
["ui/tabs/Aim"] = function(...)
-- Tab Aim: aimlock, silent aim, FOV.
local Hub = ...
local Page = Hub.use("ui/Controls")

local page = Page.new("Aim")

page:Header("Aim", "Aimlock dan silent aim ke Killer")
page:Section("Mode")
page:Toggle("Aimlock (tahan bidik)", "Aimlock")
page:Toggle("Silent Aim", "Silent")
page:Toggle("Wall Check", "WallCheck")
page:Section("Pengaturan")
page:Slider("FOV", "FOV", 30, 800, 10, " px")
page:Slider("Kekuatan kunci", "Lock", 5, 100, 5, "%")
page:Slider("Prediksi", "Predict", 0, 30, 1, "")
page:Choice("Bagian target", "Part", { "HumanoidRootPart", "Head", "Torso" })
page:Toggle("Auto reset pose (PC)", "AutoUnstick")
page:Section("Lingkaran FOV")
page:Toggle("Tampilkan FOV", "ShowFOV")
page:Color("Warna FOV", "FOVColor")

return { page = page }
end,
["ui/tabs/Dashboard"] = function(...)
-- Tab Dashboard: statistik langsung, role pemain, kontrol cepat, perbaikan, diagnostik.
-- update() dijalankan Scheduler tiap 0.5 detik.
local Hub = ...
local Players = game:GetService("Players")
local Stats = game:GetService("Stats")
local LP = Players.LocalPlayer
local Config = Hub.use("config/Config")
local Cfg, reg, setCfg = Config.Cfg, Config.reg, Config.set
local Util = Hub.use("core/Util")
local Scheduler = Hub.use("core/Scheduler")
local Roles = Hub.use("core/Roles")
local Aim = Hub.use("features/Aim")
local SkillScan = Hub.use("features/SkillScan")
local Move = Hub.use("features/Movement")
local ESP = Hub.use("esp/Players")
local Zom = Hub.use("esp/Zombies")
local Window = Hub.use("ui/Window")
local T = Hub.use("ui/Kit").T
local Page = Hub.use("ui/Controls")

local page = Page.new("Dashboard")

page:Header("Dashboard", "Ringkasan permainan")
local tiles = page:Tiles({ { "fps", "FPS" }, { "ping", "PING" }, { "players", "PEMAIN" }, { "killer", "KILLER" } })
page:Section("Role pemain")
local infoRole = page:Info("...", true)
page:Section("Kontrol cepat")
page:Toggle("Aimlock", "Aimlock")
page:Toggle("Silent Aim", "Silent")
page:Toggle("ESP Killer", "ESPKiller")
page:Toggle("ESP Survivor", "ESPSurv")
page:Toggle("ESP Zombie", "ESPZombie")
page:Toggle("Label semua ESP", "ShowLabels")
page:Toggle("Terang (Fullbright)", "Fullbright")
page:Toggle("Mode HD", "HD")
page:Section("Perbaikan")
page:Button("Reset pose (tubuh macet angkat pistol)", Aim.unstick)
local manualBtn
manualBtn = page:Button("Killer: Auto  (tap untuk ganti manual)", function()
    local names = { "" }
    for _, p in ipairs(Players:GetPlayers()) do
        if p ~= LP then names[#names + 1] = p.Name end
    end
    local idx = table.find(names, Cfg.ManualKiller) or 1
    setCfg("ManualKiller", names[idx % #names + 1])
    pcall(Roles.detect)
end)
reg("ManualKiller", function()
    manualBtn.Text = "Killer: " .. (Cfg.ManualKiller == "" and "Auto" or Cfg.ManualKiller) .. "  (tap untuk ganti)"
end)
page:Button("Salin data deteksi role", function()
    if setclipboard then
        setclipboard(Roles.dump())
        Window.toast("Data deteksi disalin")
    else
        Window.toast("setclipboard tidak didukung")
    end
end)
page:Button("Scan skill check (15 dtk, salin hasil)", function()
    if not setclipboard then Window.toast("setclipboard tidak didukung") return end
    Window.toast("Scan 15 dtk: picu skill check lalu tekan seperti biasa")
    SkillScan.start(15, function(txt)
        setclipboard(txt)
        Window.toast("Hasil scan disalin")
    end)
end)
page:Section("Twist of Fate")
local infoTOF = page:Info("...")
page:Section("Diagnostik")
local infoDiag = page:Info("...")

--------------------------------------------------------
-- Pembaruan berkala (dipecah per bagian)
--------------------------------------------------------
local function updateTiles(ping)
    local fps = Scheduler.fps
    tiles.fps.Text = tostring(math.floor(fps))
    tiles.ping.Text = ping .. " ms"
    tiles.players.Text = tostring(#Players:GetPlayers())
    local k1 = Roles.killers[1]
    tiles.killer.Text = k1 and k1.DisplayName or "-"
    tiles.killer.TextColor3 = k1 and Cfg.KillerColor or T.muted
    Window.statLbl.Text = ("%d fps · %s ms"):format(math.floor(fps), ping)
end

local function updateRoles()
    local lines = {}
    local kc, sc = "#" .. Util.hex(Cfg.KillerColor), "#" .. Util.hex(Cfg.SurvColor)
    for i, e in ipairs(Roles.info) do
        if i > 8 then lines[#lines + 1] = "..." break end
        local me = e.p == LP and " <font color=\"#8A8E9E\">(kamu)</font>" or ""
        if e.killer then
            lines[#lines + 1] = ("<font color=\"%s\"><b>KILLER</b></font>  %s%s"):format(kc, Util.esc(e.p.DisplayName), me)
        else
            lines[#lines + 1] = ("<font color=\"%s\">Survivor</font>  %s%s"):format(sc, Util.esc(e.p.DisplayName), me)
        end
    end
    if #lines == 0 then lines[1] = "Belum ada data pemain" end
    local foot = #Roles.killers > 0 and ("Target aim: " .. Util.esc(Aim.targetName or "-"))
        or "<font color=\"#8A8E9E\">Killer belum terdeteksi (muncul saat match mulai, atau pilih manual)</font>"
    infoRole.Text = table.concat(lines, "\n") .. "\n" .. foot
end

local function updateTOF()
    local total = Aim.shoot + Aim.fail
    infoTOF.Text = ("Peluru: %d    Gagal: %d%s"):format(
        Aim.shoot, Aim.fail, total > 0 and ("    (" .. math.floor(Aim.shoot / total * 100) .. "% peluru)") or "")
end

local function updateDiag()
    local zc, zt = 0, 0
    for model in pairs(Zom.tracked) do
        zt += 1
        if Cfg.ZomAll or Zom.matches(model) then zc += 1 end
    end
    local diag = {
        ("ESP pemain tampil: Killer %d, Survivor %d"):format(ESP.shown.Killer or 0, ESP.shown.Surv or 0),
        ("Zombie: %d cocok dari %d NPC, tampil %d"):format(zc, zt, Zom.shown),
        "Mode ESP: " .. Cfg.ESPMode,
    }
    local errs = {}
    for name, e in pairs(Hub.Err) do errs[#errs + 1] = name .. ": " .. e:sub(1, 70) end
    diag[#diag + 1] = #errs > 0 and ("Error:\n" .. table.concat(errs, "\n")) or "Error: tidak ada"
    infoDiag.Text = table.concat(diag, "\n")
end

local function update()
    local ping = "-"
    pcall(function() ping = tostring(math.floor(Stats.Network.ServerStatsItem["Data Ping"]:GetValue())) end)
    updateTiles(ping)
    updateRoles()
    updateTOF()
    updateDiag()
end

Scheduler.add("Dashboard", 0.5, update)

return { page = page }
end,
["ui/tabs/ESP"] = function(...)
-- Tab ESP (satu tempat untuk semua ESP): pengaturan umum + label master,
-- grup per kategori (pemain, zombie, objek map) dan info objek terdeteksi.
local Hub = ...
local Config = Hub.use("config/Config")
local Cats = Hub.use("config/Categories")
local Scheduler = Hub.use("core/Scheduler")
local Zom = Hub.use("esp/Zombies")
local Obj = Hub.use("esp/Objects")
local Window = Hub.use("ui/Window")
local Page = Hub.use("ui/Controls")
local CategoryGroup = Hub.use("ui/CategoryGroup")

local CAT = Cats.byId
local OBJ_GROUPS = Cats.objGroups
local page = Page.new("ESP")

page:Header("ESP", "Pemain, zombie, dan objek map")

page:Section("Label")
page:Toggle("Label semua ESP", "ShowLabels")
page:Toggle("Tag [KILLER]", "ShowRole")
page:Toggle("Nama", "ShowName")
page:Toggle("Jarak", "ShowDist")
page:Toggle("HP", "ShowHP")
page:Toggle("Generator: bar progres otomatis (tanpa label)", "GenBar")
page:Toggle("Generator penuh: ESP mati otomatis", "GenHideDone")
page:Slider("Ukuran teks", "TextSize", 9, 22, 1, "")

page:Section("Tampilan")
page:Slider("Transparansi isi chams", "FillT", 0, 100, 5, "%")
page:Choice("Mode ESP", "ESPMode", { "CoreGui", "Workspace" })
page:Button("Aktifkan semua ESP", function()
    for _, c in ipairs(Cats.list) do Config.set(c.on, true) end
    Window.toast("Semua ESP aktif")
end, "accent")
page:Button("Matikan semua ESP", function()
    for _, c in ipairs(Cats.list) do Config.set(c.on, false) end
    Window.toast("Semua ESP mati")
end)
page:Button("Scan ulang objek", function() Obj.rescan() Window.toast("Scan ulang dimulai") end)

page:Section("Pemain (tap untuk buka)")
CategoryGroup(page, CAT.Killer)
CategoryGroup(page, CAT.Surv)

page:Section("Zombie")
CategoryGroup(page, CAT.Zombie, function(g)
    g:Input("Kata kunci zombie", "KeyZombie", "scp2, zombie", Zom.rebuild)
    g:Toggle("Semua NPC bernyawa", "ZomAll")
end)

page:Section("Objek map")
for _, c in ipairs(OBJ_GROUPS) do CategoryGroup(page, c) end

page:Section("Objek terdeteksi")
local infoObj = page:Info("...")

Scheduler.add("Info objek", 0.5, function()
    local counts = {}
    for _, g in ipairs(OBJ_GROUPS) do counts[g.id] = 0 end
    for _, rec in pairs(Obj.tracked) do counts[rec.g.id] += 1 end
    local parts = {}
    for _, g in ipairs(OBJ_GROUPS) do
        parts[#parts + 1] = ("%s: %d terdeteksi / %d tampil"):format(g.name, counts[g.id], Obj.shown[g.id] or 0)
    end
    infoObj.Text = table.concat(parts, "\n") .. "\n0 terdeteksi = nama di game berbeda, ubah kata kunci di grup objeknya"
end)

return { page = page }
end,
["ui/tabs/Move"] = function(...)
-- Tab Gerak: speed, noclip, fly.
local Hub = ...
local Scheduler = Hub.use("core/Scheduler")
local Move = Hub.use("features/Movement")
local Page = Hub.use("ui/Controls")

local page = Page.new("Gerak")

page:Header("Gerak", "Risiko tinggi, pakai akun alt")
page:Section("Speed")
page:Toggle("Speed", "Speed")
page:Slider("Kecepatan jalan (bisa diketik)", "SpeedVal", 1, 100, 1, "")
page:Toggle("Tahan otomatis saat knockdown/digendong/digantung", "SpeedSafe")
local infoSpeed = page:Info("Status: -")
page:Section("Lainnya")
page:Toggle("Noclip", "Noclip")
page:Toggle("Terbang (Fly)", "Fly")
page:Slider("Kecepatan terbang (bisa diketik)", "FlySpeed", 10, 200, 5, "")
page:Info("Server melihat posisi karakter, jadi speed/noclip/fly bisa ditandai atau dikembalikan. Mulai dari nilai kecil.")

Scheduler.add("Info gerak", 0.5, function()
    infoSpeed.Text = "Status speed: " .. Move.status
end)

return { page = page }
end,
["ui/tabs/Settings"] = function(...)
-- Tab Settings: tampilan, config (simpan/muat), deteksi role, info, unload.
local Hub = ...
local Config = Hub.use("config/Config")
local Scheduler = Hub.use("core/Scheduler")
local Window = Hub.use("ui/Window")
local Page = Hub.use("ui/Controls")
local Theme = Hub.use("ui/Theme")
local Root = Hub.use("ui/Root")

local page = Page.new("Settings")

page:Header("Settings", "Tampilan, config, dan deteksi")

page:Section("Tampilan")
page:Choice("Tema Mario", "Theme", Theme.names)
Config.reg("Theme", function()
    Theme.apply(Config.Cfg.Theme, Root.gui)
end)
page:Color("Warna aksen UI", "Accent")
page:Toggle("Animasi UI", "UIAnim")
page:Toggle("Tombol melayang", "ShowFloat")
page:Button("Reset ukuran window", function()
    Window.resetSize()
    Window.toast("Ukuran direset")
end)
page:Button("Reset semua warna", function()
    for k, v in pairs(Config.Default) do
        if typeof(v) == "Color3" then Config.set(k, v) end
    end
    Window.toast("Warna direset")
end)

page:Section("Config")
page:Toggle("Simpan otomatis", "AutoSave")
local infoCfg = page:Info("...")
page:Button("Simpan config sekarang", function()
    local ok, msg = Config.save()
    Window.toast(msg)
end, "accent")
page:Button("Muat config", function()
    local ok, msg = Config.load()
    Window.toast(msg)
end)
page:Button("Reset semua ke default", function()
    Config.reset()
    Window.toast("Semua pengaturan dikembalikan ke default")
end)
page:Button("Salin config (JSON)", function()
    if setclipboard then
        setclipboard(Config.serialize())
        Window.toast("Config disalin ke clipboard")
    else
        Window.toast("setclipboard tidak didukung")
    end
end)
page:Button("Hapus file config", function()
    local ok, msg = Config.delete()
    Window.toast(msg)
end, "danger")

Scheduler.add("Info config", 0.5, function()
    local lines = { "File: " .. Config.FILE }
    if not Config.supported() then
        lines[#lines + 1] = "Executor tidak mendukung baca/tulis file, config tidak bisa disimpan"
    else
        lines[#lines + 1] = Config.exists() and "File config: ada" or "File config: belum dibuat"
        lines[#lines + 1] = Config.dirty and "Status: ada perubahan belum tersimpan" or "Status: tersimpan"
        if Config.lastSave then
            lines[#lines + 1] = ("Terakhir disimpan: %d detik lalu"):format(os.time() - Config.lastSave)
        end
    end
    infoCfg.Text = table.concat(lines, "\n")
end)

page:Section("Deteksi role")
page:Slider("Jumlah killer", "KillerCount", 1, 3, 1, "")
page:Section("Info")
page:Info("RightShift: tampil/sembunyi window\nTombol ? melayang: tap buka/tutup, geser untuk pindah\nTombol – : minimize | ◢ : ubah ukuran\nAngka di slider bisa diketik\nSimpan otomatis aktif: perubahan tersimpan 1 detik setelah diubah. Matikan bila ingin menyimpan manual.")
page:Section("Script")
page:Button("Unload", function() Hub.unload() end, "danger")

return { page = page }
end,
["ui/tabs/ViolenceDistrict"] = function(...)
-- Tab Violence District: Auto Skill Check + Speed Boost + Fast Vaulting.
local Hub = ...
Hub.use("features/AutoSkillCheck")
local FV = Hub.use("features/FastVault")
local Scheduler = Hub.use("core/Scheduler")
local Window = Hub.use("ui/Window")
local Page = Hub.use("ui/Controls")

local page = Page.new("Violence District")

page:Header("Violence District", "Skill check, speed boost, dan fast vault")
page:Section("Generator / Skill Check")
page:Toggle("Auto Skill Check", "VDAutoSkillCheck")
page:Choice("Mode Skill Check", "VDSkillMode", { "Perfect", "Normal", "Instant" })
page:Section("Movement")
page:Toggle("Speed Boost", "VDSpeedBoost")
page:Slider("Boost Multiplier", "VDSpeedMultiplier", 0, 2, 0.05, "x")
page:Toggle("Speed Safe Mode", "VDSpeedSafeMode")
page:Section("Vault (jendela)")
page:Toggle("Fast Vaulting", "VDFastVault")
page:Toggle("Paksa vault fast (tanpa syarat lari)", "VDVaultForce")
page:Toggle("Tampilan animasi fast asli", "VDVaultAnim")
page:Choice("Metode", "VDVaultMode", { "Atribut", "Animasi" })
page:Slider("Kecepatan vault", "VDVaultMult", 1, 2.5, 0.25, "x")
page:Input("Kata kunci animasi (metode Animasi)", "VDVaultKeys", "vault", FV.rebuild)
local infoVault = page:Info("...")
page:Button("Bersihkan daftar animasi", function()
    FV.clearRecent()
    Window.toast("Daftar animasi dibersihkan")
end)
page:Info("Atribut: mengalikan atribut karakter vaultspeed (cara bawaan game). Animasi: mempercepat animasi vault langsung (kata kunci default \"vault\" cocok dengan RunningVaultAnimation). Bila satu metode tidak terasa, coba yang lain. Server tetap menerima sinyal vault lebih cepat dari biasanya, jadi pakai 1.5x dulu (server membatasi kecepatan vault ~30 stud/dtk). Paksa vault fast: argumen tier di VaultEvent diganti \"fast\" walau kamu tidak sedang lari; bila server menolak/macet, matikan.")
Scheduler.add("Info vault", 0.5, function()
    local recent = #FV.recent > 0 and table.concat(FV.recent, ", ") or "-"
    infoVault.Text = "Status: " .. FV.status .. "\nHook tier: " .. (FV.hooked and ("aktif, dipaksa " .. FV.forced .. "x") or "tidak didukung executor") .. "\nAnimasi terakhir (sekali putar): " .. recent
end)
page:Section("Catatan")
page:Info("Safe Mode menjeda boost saat kondisi aksi/terbatas terdeteksi atau HP <= 50. Jangan aktifkan bersamaan dengan Speed di tab Gerak. WalkSpeed dapat ditimpa server.")

return { page = page }
end,
["ui/tabs/World"] = function(...)
-- Tab Dunia: pencahayaan + HD grafis.
local Hub = ...
local World = Hub.use("features/World")
local Page = Hub.use("ui/Controls")

local page = Page.new("Dunia")

page:Header("Dunia", "Pencahayaan dan grafis HD")

page:Section("HD grafis")
page:Toggle("Mode HD", "HD")
page:Choice("Preset HD", "HDPreset", World.PRESET_NAMES, World.applyPreset)
page:Slider("Kontras", "HDContrast", 0, 40, 1, "%")
page:Slider("Saturasi warna", "HDSaturation", 0, 40, 1, "%")
page:Slider("Bloom (cahaya lembut)", "HDBloom", 0, 100, 5, "%")
page:Toggle("Bayangan tajam", "HDShadows")
page:Toggle("Kualitas render maksimum", "HDQuality")
page:Toggle("Detail mesh maksimum (berat)", "HDMesh")
page:Toggle("Future lighting (jika executor mendukung)", "HDFuture")
page:Info("HD hanya mengubah tampilan di layarmu (client). Mesh maksimum dan Future lighting bisa berat di HP/PC lemah; matikan bila FPS turun.")

page:Section("Pencahayaan")
page:Toggle("Fullbright", "Fullbright")
page:Slider("Kecerahan", "Bright", 0, 6, 0.5, "")
page:Color("Warna ambient (tema)", "AmbientColor")
page:Section("Tambahan")
page:Toggle("Hilangkan kabut", "NoFog")
page:Toggle("Matikan efek gelap (blur/bloom/dll)", "NoFx")
page:Toggle("Kunci waktu (jam)", "ForceTime")
page:Slider("Jam", "Time", 0, 24, 0.5, "")

return { page = page }
end,
}

local Hub = { Dead = false, Err = {}, conns = {}, cleanups = {}, cache = {}, loading = {} }

--------------------------------------------------------
-- Utilitas inti yang dipakai semua modul
--------------------------------------------------------
-- sambungkan event supaya otomatis diputus saat unload
function Hub.track(c)
    Hub.conns[#Hub.conns + 1] = c
    return c
end

-- jalankan fungsi aman; error disimpan dan tampil di Dashboard > Diagnostik
function Hub.safe(name, fn, ...)
    local ok, e = pcall(fn, ...)
    if ok then
        Hub.Err[name] = nil
    else
        e = tostring(e)
        if Hub.Err[name] ~= e then warn("[TOFHub] " .. name .. ": " .. e) end
        Hub.Err[name] = e
    end
end

-- daftarkan pembersih; dijalankan terbalik (daftar terakhir = jalan pertama) saat unload
function Hub.onUnload(fn)
    Hub.cleanups[#Hub.cleanups + 1] = fn
end

--------------------------------------------------------
-- Loader modul
--------------------------------------------------------
local function readSource(name)
    local path = name .. ".lua"
    if BASE_URL then
        local stamp = tostring(os.time()) .. tostring(math.floor(os.clock() * 1000))
        return game:HttpGet(BASE_URL .. path .. "?v=" .. stamp)
    end
    return readfile(ROOT .. "/" .. path)
end

function Hub.use(name)
    local cached = Hub.cache[name]
    if cached ~= nil then return cached end
    if Hub.loading[name] then error("dependensi melingkar: " .. name, 0) end
    Hub.loading[name] = true

    local chunk
    if BUNDLE then
        chunk = BUNDLE[name]
        if not chunk then error("modul tidak ada di bundle: " .. name, 0) end
    else
        local f, e = loadstring(readSource(name), "=" .. name)
        if not f then error("sintaks " .. name .. ": " .. tostring(e), 0) end
        chunk = f
    end

    local ok, res = pcall(chunk, Hub)
    Hub.loading[name] = nil
    if not ok then error("modul " .. name .. ": " .. tostring(res), 0) end
    if res == nil then res = true end
    Hub.cache[name] = res
    return res
end

function Hub.unload()
    if Hub.Dead then return end
    Hub.Dead = true
    for i = #Hub.cleanups, 1, -1 do pcall(Hub.cleanups[i]) end
    for _, c in ipairs(Hub.conns) do pcall(function() c:Disconnect() end) end
end
if getgenv then getgenv().TOFHubUnload = Hub.unload end

--------------------------------------------------------
-- Daftar modul yang dijalankan (urutan tab = urutan di sini)
--------------------------------------------------------
local BOOT = {
    -- logika
    "core/Roles", "features/Aim", "features/World", "features/Movement",
    "esp/Players", "esp/Zombies", "esp/Objects",
    -- UI dasar
    "ui/Window", "ui/FovCircle",
    -- tab (urutan = urutan di sidebar; tambah tab baru = tambah satu baris)
    "ui/tabs/Dashboard", "ui/tabs/Aim", "ui/tabs/ESP",
    "ui/tabs/World", "ui/tabs/Move", "ui/tabs/ViolenceDistrict", "ui/tabs/Settings",
    "ui/FloatButton",
}

local ok, err = pcall(function()
    for _, name in ipairs(BOOT) do Hub.use(name) end
    local Page = Hub.use("ui/Page")
    Page.select(Page.list[1])
end)
if not ok then
    warn("[TOFHub] gagal start: " .. tostring(err))
    Hub.unload()
end
